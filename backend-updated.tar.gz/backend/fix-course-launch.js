const mongoose = require('mongoose');
require('dotenv').config();

mongoose.connect(process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/sgt-lms').then(async () => {
  const Course = require('./models/Course');
  const Video = require('./models/Video');
  const ReadingMaterial = require('./models/ReadingMaterial');
  
  // Find the course 'dont touch this'
  const course = await Course.findOne({ title: { $regex: 'dont touch', $options: 'i' } });
  if (!course) {
    console.log('Course not found');
    process.exit(1);
  }
  
  console.log('Found course:', course.title, course._id.toString());
  console.log('Current isLaunched:', course.isLaunched);
  
  // Mark as launched
  course.isLaunched = true;
  course.launchedAt = new Date();
  await course.save();
  console.log('✅ Course marked as launched');
  
  // Find and update recent videos to pending (uploaded in last 2 hours)
  const twoHoursAgo = new Date(Date.now() - 2 * 60 * 60 * 1000);
  const recentVideos = await Video.find({ 
    course: course._id,
    createdAt: { $gt: twoHoursAgo }
  });
  
  console.log('Recent videos found:', recentVideos.length);
  for (const video of recentVideos) {
    console.log('  Updating video:', video.title, '- was isApproved:', video.isApproved);
    video.isApproved = false;
    video.approvalStatus = 'pending';
    video.addedAfterLaunch = true;
    await video.save();
    console.log('    ✅ Now pending approval');
  }
  
  // Also check recent documents
  const recentDocs = await ReadingMaterial.find({
    course: course._id,
    createdAt: { $gt: twoHoursAgo }
  });
  
  console.log('Recent documents found:', recentDocs.length);
  for (const doc of recentDocs) {
    console.log('  Updating document:', doc.title, '- was isApproved:', doc.isApproved);
    doc.isApproved = false;
    doc.approvalStatus = 'pending';
    doc.addedAfterLaunch = true;
    await doc.save();
    console.log('    ✅ Now pending approval');
  }
  
  console.log('\n✅ Done! Course is now launched and recent content requires approval.');
  process.exit(0);
}).catch(err => { 
  console.error('Error:', err); 
  process.exit(1); 
});
