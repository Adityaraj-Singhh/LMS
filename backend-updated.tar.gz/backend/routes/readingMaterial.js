const express = require('express');
const router = express.Router();
const readingMaterialController = require('../controllers/readingMaterialController');
const { auth, authorizeRoles } = require('../middleware/auth');
const { validateContentAccess } = require('../middleware/contentValidationMiddleware');
const upload = require('../middleware/upload')('documents');
const ReadingMaterial = require('../models/ReadingMaterial');
const S3Service = require('../services/s3Service');
const crypto = require('crypto');

const s3Service = new S3Service();

// Store for secure document tokens (in production, use Redis)
const documentTokenStore = new Map();

// Token expiration time (15 minutes)
const TOKEN_EXPIRATION = 15 * 60 * 1000;

// Clean up expired tokens periodically
setInterval(() => {
  const now = Date.now();
  for (const [token, data] of documentTokenStore.entries()) {
    if (now > data.expiresAt) {
      documentTokenStore.delete(token);
    }
  }
}, 60000); // Clean up every minute

// Teacher routes
router.post('/', 
  auth, 
  authorizeRoles('teacher', 'admin'), 
  upload.single('file'), 
  readingMaterialController.createReadingMaterial
);

router.put('/:materialId', 
  auth, 
  authorizeRoles('teacher', 'admin'), 
  upload.single('file'), 
  readingMaterialController.updateReadingMaterial
);

router.delete('/:materialId', 
  auth, 
  authorizeRoles('teacher', 'admin'), 
  readingMaterialController.deleteReadingMaterial
);

// Common routes
router.get('/:materialId', auth, readingMaterialController.getReadingMaterial);
router.get('/unit/:unitId', auth, readingMaterialController.getUnitReadingMaterials);

// Get signed URL for reading material preview
// Get signed URL for reading material preview - with content validation
// NOTE: This now returns a secure proxy token instead of the actual S3 URL
router.get('/:materialId/signed-url', auth, validateContentAccess, async (req, res) => {
  try {
    const { materialId } = req.params;
    const userId = req.user._id || req.user.id;

    console.log(`📖 Generating secure document token for reading material: ${materialId}`);

    // Find the reading material
    const material = await ReadingMaterial.findById(materialId);
    if (!material) {
      return res.status(404).json({ message: 'Reading material not found' });
    }

    // Check if material has a file URL
    if (!material.fileUrl) {
      return res.status(400).json({ message: 'Reading material has no file associated' });
    }

    // Generate a secure token for document access
    const secureToken = crypto.randomBytes(32).toString('hex');
    
    // Store token with material info and expiration
    documentTokenStore.set(secureToken, {
      materialId: materialId,
      userId: userId.toString(),
      fileUrl: material.fileUrl,
      title: material.title,
      contentType: material.contentType,
      createdAt: Date.now(),
      expiresAt: Date.now() + TOKEN_EXPIRATION
    });

    console.log(`✅ Generated secure token for reading material: ${material.title}`);

    // Return proxy URL instead of S3 URL
    // The actual S3 URL is never exposed to the frontend
    const proxyUrl = `/api/reading-materials/secure-view/${secureToken}`;

    res.json({
      signedUrl: proxyUrl,
      title: material.title,
      contentType: material.contentType,
      expiresIn: TOKEN_EXPIRATION / 1000,
      contentDisposition: 'inline',
      isSecureProxy: true
    });

  } catch (error) {
    console.error('Error generating reading material signed URL:', error);
    res.status(500).json({ message: 'Failed to generate reading material preview URL' });
  }
});

// Secure document proxy - streams document without exposing S3 URL
router.get('/secure-view/:token', async (req, res) => {
  try {
    const { token } = req.params;

    // Validate token
    const tokenData = documentTokenStore.get(token);
    if (!tokenData) {
      console.error('❌ Invalid or expired document token');
      return res.status(403).json({ message: 'Invalid or expired document access token' });
    }

    // Check if token has expired
    if (Date.now() > tokenData.expiresAt) {
      documentTokenStore.delete(token);
      console.error('❌ Document token expired');
      return res.status(403).json({ message: 'Document access token has expired' });
    }

    console.log(`🔒 Secure document access: ${tokenData.title} (Material: ${tokenData.materialId})`);

    // Extract S3 key from file URL
    const s3Key = s3Service.extractKeyFromUrl(tokenData.fileUrl);
    if (!s3Key) {
      console.error('❌ Could not extract S3 key from file URL:', tokenData.fileUrl);
      return res.status(400).json({ message: 'Invalid file URL format' });
    }

    // Get the file from S3
    const s3Object = await s3Service.getObject(s3Key);

    // Determine content type
    let contentType = s3Object.ContentType || 'application/octet-stream';
    
    // Map file extensions to content types if needed
    const fileExt = s3Key.split('.').pop().toLowerCase();
    const contentTypeMap = {
      'pdf': 'application/pdf',
      'doc': 'application/msword',
      'docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'ppt': 'application/vnd.ms-powerpoint',
      'pptx': 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
      'xls': 'application/vnd.ms-excel',
      'xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    };
    
    if (contentTypeMap[fileExt]) {
      contentType = contentTypeMap[fileExt];
    }

    // Set security headers
    res.setHeader('Content-Type', contentType);
    res.setHeader('Content-Disposition', 'inline');
    res.setHeader('Content-Length', s3Object.ContentLength);
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    res.setHeader('Pragma', 'no-cache');
    res.setHeader('Expires', '0');
    
    // Prevent framing by other sites
    res.setHeader('X-Frame-Options', 'SAMEORIGIN');
    
    // Security: Prevent downloads via Content-Security-Policy
    res.setHeader('Content-Security-Policy', "default-src 'self'; frame-ancestors 'self'");

    console.log(`✅ Streaming document: ${tokenData.title} (${s3Object.ContentLength} bytes)`);

    // Stream the document content
    res.send(s3Object.Body);

  } catch (error) {
    console.error('Error in secure document proxy:', error);
    res.status(500).json({ message: 'Failed to load document' });
  }
});

// Secure document stream endpoint - for iframe/embed viewing
router.get('/secure-stream/:token', async (req, res) => {
  try {
    const { token } = req.params;

    // Validate token
    const tokenData = documentTokenStore.get(token);
    if (!tokenData) {
      console.error('❌ Invalid or expired document token for stream');
      return res.status(403).send('Access denied');
    }

    // Check if token has expired
    if (Date.now() > tokenData.expiresAt) {
      documentTokenStore.delete(token);
      console.error('❌ Document stream token expired');
      return res.status(403).send('Token expired');
    }

    // Extract S3 key from file URL
    const s3Key = s3Service.extractKeyFromUrl(tokenData.fileUrl);
    if (!s3Key) {
      return res.status(400).send('Invalid document');
    }

    // Get file extension
    const fileExt = s3Key.split('.').pop().toLowerCase();
    
    // **FIX: For Office documents (DOC, PPT, Excel, TXT), check if we're on HTTPS before using Google Docs viewer**
    if (['doc', 'docx', 'ppt', 'pptx', 'xls', 'xlsx', 'txt'].includes(fileExt)) {
      const protocol = req.protocol || (req.headers['x-forwarded-proto'] || 'http');
      
      if (protocol === 'https') {
        // HTTPS: Safe to use Google Docs viewer
        const signedUrl = s3Service.getSignedUrl(s3Key, 300); // 5 minutes only
        const viewerUrl = `https://docs.google.com/viewer?url=${encodeURIComponent(signedUrl)}&embedded=true`;
        
        console.log(`📄 Redirecting Office document to Google Docs viewer: ${tokenData.title}`);
        return res.redirect(viewerUrl);
      } else {
        // HTTP: Use Office Online viewer or return HTML with embedded viewer
        console.log(`⚠️ HTTP detected - using alternative viewer for Office document: ${tokenData.title}`);
        
        // Generate signed URL for direct viewing
        const signedUrl = s3Service.getSignedUrl(s3Key, 3600); // 1 hour for office docs
        
        // For TXT files, display as plain text
        if (fileExt === 'txt') {
          const s3Object = await s3Service.getObject(s3Key);
          res.setHeader('Content-Type', 'text/plain; charset=utf-8');
          res.setHeader('Content-Disposition', 'inline');
          return res.send(s3Object.Body);
        }
        
        // Return HTML page with Microsoft Office Online viewer for DOC/PPT/Excel
        const viewerHtml = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${tokenData.title || 'Document'}</title>
  <style>
    body, html { margin: 0; padding: 0; height: 100%; overflow: hidden; }
    iframe { width: 100%; height: 100%; border: none; }
  </style>
</head>
<body>
  <iframe src="https://view.officeapps.live.com/op/embed.aspx?src=${encodeURIComponent(signedUrl)}" 
          frameborder="0">
    This is an embedded Microsoft Office document, powered by Office.
  </iframe>
</body>
</html>`;
        
        res.setHeader('Content-Type', 'text/html');
        return res.send(viewerHtml);
      }
    }

    // For PDFs, stream directly
    const s3Object = await s3Service.getObject(s3Key);
    
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', 'inline');
    res.setHeader('Content-Length', s3Object.ContentLength);
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Cache-Control', 'private, no-cache');
    
    res.send(s3Object.Body);

  } catch (error) {
    console.error('Error in secure document stream:', error);
    res.status(500).send('Failed to load document');
  }
});

// Student routes
router.post('/:materialId/complete', 
  auth, 
  authorizeRoles('student'), 
  readingMaterialController.markAsCompleted
);

router.get('/student/course/:courseId', 
  auth, 
  authorizeRoles('student'), 
  readingMaterialController.getStudentReadingMaterialStatus
);

module.exports = router;
