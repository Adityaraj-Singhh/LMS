
# LMS Dashboard User Guide (Detailed)

This guide explains, in detail, the purpose, rights, and workflow for every dashboard in the LMS. Each section describes what the user can do, why each step is needed, and the correct order of operations.

---

## 1. Admin Dashboard

### Description
The Admin Dashboard is the control center for the entire LMS. Admins have the highest level of access and are responsible for setting up the system, managing all users, and maintaining the academic structure. Every other dashboard depends on the initial setup done here.

### Rights
- Create, edit, and delete all entities (schools, departments, users, courses, sections, content, quizzes, etc.)
- Assign roles (Dean, HOD, Teacher, Student)
- Unlock quizzes, monitor progress, and manage certificates
- Access all analytics, audit logs, and communication tools

### Detailed Workflow
1. **Create School**
   - _Why:_ All other entities (departments, courses, users) must belong to a school. This is always the first step.
   - _How:_ Go to **Schools** → Click **Create School** → Fill in details → Save.
2. **Create Department**
   - _Why:_ Departments are subdivisions within a school. You cannot create a department unless a school exists.
   - _How:_ Go to **Departments** → Click **Create Department** → Select school → Fill in details → Save.
3. **Assign Dean**
   - _Why:_ Each school should have a dean for management and oversight.
   - _How:_ Go to **Deans** → Click **Add Dean** → Select school → Fill in details → Save.
4. **Assign HOD**
   - _Why:_ Each department should have a Head of Department (HOD) for academic management.
   - _How:_ Go to **HODs** → Click **Add HOD** → Select department → Fill in details → Save.
5. **Add Teachers**
   - _Why:_ Teachers must be assigned to departments (and optionally to schools).
   - _How:_ Go to **Teachers** → Click **Add Teacher** → Select department/school → Fill in details → Save.
6. **Add Students**
   - _Why:_ Students must be assigned to departments and sections.
   - _How:_ Go to **Students** → Click **Add Student** or **Bulk Upload** → Select department and section → Fill in details → Save.
7. **Create Courses**
   - _Why:_ Courses are linked to departments and schools. You cannot create a course without a department.
   - _How:_ Go to **Courses** → Click **Add Course** → Select school and department → Fill in details → Save.
8. **Create Sections**
   - _Why:_ Sections are groups within a course for organizing students and teachers. You cannot create a section without a course.
   - _How:_ Go to **Sections** → Click **Create Section** → Select course, department, and school → Fill in details → Save.
9. **Assign Teachers and Students to Sections**
   - _Why:_ Sections need teachers to deliver content and students to participate.
   - _How:_ Go to **Sections** → Select a section → Assign teachers and students from the lists.
10. **Upload Course Content (Videos, Documents, Quizzes)**
    - _Why:_ Content must be linked to courses and sections. You cannot upload content until courses exist.
    - _How:_ Go to **Courses** → Select a course → Go to **Content/Modules** → Add videos, documents, quizzes.
   - _Components:_ **VideoManagement**, **QuizManagement**, **CourseManagement**.
11. **Upload Closed Captions (CC) for Videos**
    - _Why:_ For accessibility, upload CC files with videos.
    - _How:_ During video upload, attach a `.vtt` or `.srt` file as the CC file.
12. **Arrange Content Order & Unlock Flow**
    - _Why:_ Students should complete content in a specific order. Unlocks depend on this arrangement.
    - _How:_ In the course content area, drag and drop or set the sequence for videos, documents, and quizzes.
13. **Quiz Management**
    - _Why:_ Quizzes test student understanding and are linked to modules/sections. Unlocks can be set based on content completion.
    - _How:_ Go to **Courses** → Select course → Go to **Quizzes** → Add quiz, assign to module/section, set unlock conditions.
   - _Components:_ **QuizManagement**, **AdminQuizUnlockDashboard**.
14. **Monitor Progress & Unlocks**
    - _Why:_ To track student progress and manually unlock quizzes if needed.
    - _How:_ Use **Sections**, **Students**, and **Quiz Unlock Dashboard**.
   - _Components:_ **SectionManagement**, **StudentManagement**, **UnlockRequests**, **AdminQuizUnlockDashboard**, **AdvancedAuditLogDashboard**, **Analytics**, **EnhancedAnalytics**.
15. **Certificates**
    - _Why:_ To recognize course completion.
    - _How:_ Configure, issue, and manage certificates.
16. **Communication & Analytics**
    - _Why:_ For announcements, chats, and tracking system usage.
    - _How:_ Use **Announcements**, **Chats**, **Analytics**, **Audit Logs**.
   - _Components:_ **AnnouncementPage**, **ChatDashboard**, **AnalyticsDashboard**, **EnhancedAnalytics**, **AdvancedAuditLogDashboard**.

---

## 2. Dean Dashboard

### Description
The Dean Dashboard is for users who oversee one or more schools. Deans have management rights over all departments, HODs, teachers, and students within their assigned school(s).

### Rights
- Manage assigned school(s)
- Oversee departments, HODs, teachers, and students
- View analytics and reports for their school

### Detailed Workflow
1. **Monitor Departments**
   - View and manage departments under their school.
2. **Oversee HODs, Teachers, Students**
   - View lists, monitor assignments, and progress.
3. **Approve/Monitor Courses**
   - Oversee courses offered in their school.
4. **View Analytics & Reports**
   - Access school-wide analytics and reports.

### Key Features (from codebase)
- **DeanDashboardHome**: Summary cards and navigation.
- **DeanSchoolManagement**: Manage schools (view/edit where permitted).
- **DeanDepartments**: List departments under assigned schools.
- **DeanCourses**: Overview of courses at school level.
- **DeanTeachers**: View teacher roster and assignments.
- **DeanSections** (via analytics pages): Section analytics and performance.
- **DeanCertificates**: Monitor certificate issuance.
- **DeanAnnouncements** and **DeanAnnouncementHistory**: Send and review announcements.
- **DeanAnalytics / DeanCourseAnalytics / DeanDepartmentAnalytics / DeanSectionAnalytics**: Detailed performance dashboards.

---

## 3. HOD Dashboard

### Description
The HOD (Head of Department) Dashboard is for managing a specific department. HODs oversee teachers, students, and courses within their department.

### Rights
- Manage assigned department(s)
- Oversee teachers and students
- Assign teachers to courses/sections
- View department analytics

### Detailed Workflow
1. **Manage Teachers**
   - Assign teachers to courses/sections within the department.
2. **Monitor Students**
   - View student lists and progress.
3. **Oversee Courses & Content**
   - Manage courses and content in the department.
4. **View Department Analytics**
   - Access department-level analytics and reports.

### Key Features (from codebase)
- **HODDashboardHome**: Department overview and quick links.
- **HODTeachers**: Manage/view teachers in the department.
- **HODSections**: Manage sections within department courses.
- **HODCourses**: Department course list and details.
- **HODContentApprovalPage**: Approve content changes/uploads from teachers.
- **HODVideoUnlockApproval**: Approve student video unlock requests.
- **HODQuizManagement / HODQuizReport / HODQuizUnlockDashboard**: Manage quizzes, reports, and manual unlocks.
- **HODCCManagement**: Oversee closed caption files and compliance.
- **HODCertificates**: Monitor certificate eligibility and issuance.
- **HODAnnouncements / HODAnnouncementHistory**: Department announcements management.
- **HODAnalytics**: Department-level analytics.

---

## 4. Teacher Dashboard

### Description
The Teacher Dashboard is for faculty members responsible for delivering course content, managing sections, and assessing students.

### Rights
- Manage assigned courses and sections
- Upload and arrange course content (videos, docs, quizzes)
- Grade quizzes and assignments
- Communicate with students

### Detailed Workflow
1. **View Assigned Courses/Sections**
   - See list of courses and sections they are teaching.
2. **Upload Content (Videos, Docs, Quizzes, CC)**
   - Add videos, documents, quizzes, and CC files to their courses.
3. **Arrange Content Order**
   - Set the sequence for content delivery.
4. **Manage Quizzes**
   - Create, assign, and grade quizzes.
5. **Monitor Student Progress**
   - Track student completion, quiz scores, and engagement.
6. **Send Announcements/Chat**
   - Communicate with students via announcements and chat.

### Key Features (from codebase)
- **TeacherDashboardHome**: Teaching overview stats (courses, students, videos, sections, quizzes).
- **TeacherCourses / TeacherCourseDetail**: Manage course-specific details and content.
- **TeacherVideos**: Upload/manage videos; attach CC; set order.
- **TeacherQuizzes / QuizAnalytics**: Create/manage quizzes and view analytics.
- **TeacherStudents / TeacherStudentAnalytics**: Monitor student lists and progress per course/section.
- **TeacherForums / TeacherForumDetail**: Handle course discussions.
- **TeacherAnnouncements / TeacherAnnouncementHistory**: Communicate with enrolled students.
- **TeacherCCManagement**: Manage closed captions for accessibility.
- **TeacherAnalytics / TeacherEnhancedAnalytics**: Advanced teaching analytics.
- **TeacherRequestPage**: View/respond to student requests (e.g., unlocks).

---

## 5. Student Dashboard

### Description
The Student Dashboard is for learners to access their assigned courses and sections, complete content, and track their progress.

### Rights
- Access assigned courses and sections
- View and complete course content (videos, docs, quizzes)
- Download certificates (if eligible)
- Communicate with teachers

### Detailed Workflow
1. **View Enrolled Courses/Sections**
   - See all assigned courses and sections.
2. **Complete Content in Order**
   - Watch videos, read documents, and complete quizzes as they unlock.
3. **Attempt Quizzes (as unlocked)**
   - Attempt quizzes after completing prerequisite content.
4. **Track Progress**
   - Monitor which content is completed/unlocked.
5. **Download Certificates**
   - Download certificates after course completion (if enabled).
6. **Receive Announcements/Chat**
   - Get updates and communicate with teachers.

### Key Features (from codebase)
- **StudentHomeDashboard**: Overview of enrolled courses and activity.
- **StudentCoursesPage / StudentCourseDetail** (via units pages): Navigate courses.
- **StudentCourseUnits / StudentCourseVideos / StudentUnitVideo**: Consume video lessons; supports CC; tracks watch history.
- **StudentForumPage / StudentForumDetailPage / StudentUnansweredForumsPage**: Participate in discussions.
- **StudentQuizPage / QuizLauncher / SecureQuizPage**: Attempt quizzes, including secure mode.
- **StudentCourseProgress**: View detailed course progress.

---

## Key Dependency Rules

- You cannot create a department without a school.
- You cannot create a course or section without a department (and school).
- You cannot assign teachers/students to sections until those sections exist.
- You cannot upload content until courses exist.
- Quiz/content unlocks depend on the arrangement set in the course.

---

**Always start with the highest-level entity (School), then move down (Department → Dean/HOD → Teachers/Students → Courses → Sections → Assignments → Content → Quizzes → Monitoring). Each step unlocks the next, ensuring a logical and error-free setup.**
