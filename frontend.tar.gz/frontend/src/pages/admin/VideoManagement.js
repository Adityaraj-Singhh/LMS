import React from 'react';
import { Typography, Paper } from '@mui/material';

const VideoManagement = () => (
  <Paper sx={{ p: 3 }}>
    <Typography variant="h6">Manage Videos</Typography>
    {/* Upload/Remove/Warn videos here */}
  </Paper>
);

export default VideoManagement;
