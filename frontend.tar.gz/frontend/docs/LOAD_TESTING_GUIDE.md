# Load Testing Guide for SGT-LMS

## Overview

This guide provides instructions for load testing the SGT-LMS API using open-source tools like k6 and Apache JMeter.

---

## Setup: k6 Load Testing

### Installation

1. **Install k6** (Windows, Mac, or Linux)
   ```bash
   # Windows (using Chocolatey)
   choco install k6

   # Mac (using Homebrew)
   brew install k6

   # Linux (using package manager)
   sudo apt-get install k6
   ```

2. **Verify Installation**
   ```bash
   k6 version
   ```

### Basic k6 Script Template

Create a file named `load-test.js`:

```javascript
import http from 'k6/http';
import { check, sleep } from 'k6';

const BASE_URL = 'http://ec2-65-0-56-84.ap-south-1.compute.amazonaws.com/api';

export const options = {
  stages: [
    { duration: '2m', target: 10 },    // Ramp up to 10 users over 2 minutes
    { duration: '5m', target: 30 },    // Ramp up to 30 users over 5 minutes
    { duration: '2m', target: 0 },     // Ramp down to 0 users over 2 minutes
  ],
  thresholds: {
    http_req_duration: ['p(95)<500', 'p(99)<1000'],  // 95% of requests < 500ms, 99% < 1000ms
    http_req_failed: ['rate<0.1'],                   // Error rate < 10%
  },
};

export default function () {
  // Simulate user login
  const loginRes = http.post(`${BASE_URL}/auth/login`, {
    email: 'dean@example.com',
    password: 'password123',
  });

  const token = loginRes.json('token');

  // Check login was successful
  check(loginRes, {
    'login succeeded': (r) => r.status === 200,
    'token received': (r) => r.json('token') !== null,
  });

  // Simulate dashboard access
  const dashRes = http.get(`${BASE_URL}/dean/overview`, {
    headers: { Authorization: `Bearer ${token}` },
  });

  check(dashRes, {
    'dashboard loaded': (r) => r.status === 200,
    'response time < 500ms': (r) => r.timings.duration < 500,
  });

  sleep(1);
}
```

### Run k6 Tests

```bash
# Basic test run
k6 run load-test.js

# Run with custom configuration
k6 run --vus 50 --duration 5m load-test.js

# Generate HTML report
k6 run --out html=report.html load-test.js
```

---

## Load Testing Scenarios

### Scenario 1: Light Load Test

**Script: `light-load-test.js`**

```javascript
import http from 'k6/http';
import { check, sleep } from 'k6';

const BASE_URL = 'http://ec2-65-0-56-84.ap-south-1.compute.amazonaws.com/api';

export const options = {
  stages: [
    { duration: '1m', target: 5 },     // 5 concurrent users
    { duration: '2m', target: 5 },     // Hold for 2 minutes
    { duration: '1m', target: 0 },     // Ramp down
  ],
  thresholds: {
    http_req_duration: ['p(95)<300'],
    http_req_failed: ['rate<0.05'],
  },
};

export default function () {
  // Login
  const loginRes = http.post(`${BASE_URL}/auth/login`, {
    email: 'dean@example.com',
    password: 'password123',
  });

  const token = loginRes.json('token');

  // Get dashboard
  http.get(`${BASE_URL}/dean/overview`, {
    headers: { Authorization: `Bearer ${token}` },
  });

  // Get announcements
  http.get(`${BASE_URL}/notifications?limit=10`, {
    headers: { Authorization: `Bearer ${token}` },
  });

  // Get departments
  http.get(`${BASE_URL}/dean/departments`, {
    headers: { Authorization: `Bearer ${token}` },
  });

  sleep(2);
}
```

**Run:**
```bash
k6 run light-load-test.js
```

**Expected Results:**
- Response time: < 300ms
- Error rate: < 5%
- Success rate: > 95%

---

### Scenario 2: Medium Load Test

**Script: `medium-load-test.js`**

```javascript
import http from 'k6/http';
import { check, sleep } from 'k6';

const BASE_URL = 'http://ec2-65-0-56-84.ap-south-1.compute.amazonaws.com/api';

export const options = {
  stages: [
    { duration: '2m', target: 20 },    // Ramp up to 20 users
    { duration: '5m', target: 20 },    // Hold for 5 minutes
    { duration: '2m', target: 0 },     // Ramp down
  ],
  thresholds: {
    http_req_duration: ['p(95)<500', 'p(99)<1000'],
    http_req_failed: ['rate<0.1'],
  },
};

let token = '';

export default function () {
  // Login (only first user)
  if (!token) {
    const loginRes = http.post(`${BASE_URL}/auth/login`, {
      email: 'dean@example.com',
      password: 'password123',
    });
    token = loginRes.json('token');
  }

  // Simulate real user activities
  const deanOverviewRes = http.get(`${BASE_URL}/dean/overview`, {
    headers: { Authorization: `Bearer ${token}` },
  });

  check(deanOverviewRes, {
    'Dashboard loaded': (r) => r.status === 200,
    'Has stats': (r) => r.json('stats') !== null,
  });

  // Get department list
  const deptsRes = http.get(`${BASE_URL}/dean/departments`, {
    headers: { Authorization: `Bearer ${token}` },
  });

  check(deptsRes, {
    'Departments loaded': (r) => r.status === 200,
    'Is array': (r) => Array.isArray(r.json()),
  });

  // Get notifications
  const notifRes = http.get(`${BASE_URL}/notifications?limit=20`, {
    headers: { Authorization: `Bearer ${token}` },
  });

  check(notifRes, {
    'Notifications loaded': (r) => r.status === 200,
    'Has notifications': (r) => r.json('notifications') !== null,
  });

  // Get analytics
  const analyticsRes = http.get(`${BASE_URL}/dean/analytics?metric=engagement`, {
    headers: { Authorization: `Bearer ${token}` },
  });

  check(analyticsRes, {
    'Analytics loaded': (r) => r.status === 200,
  });

  sleep(3);
}
```

**Run:**
```bash
k6 run medium-load-test.js
```

**Expected Results:**
- 95th percentile response time: < 500ms
- 99th percentile response time: < 1000ms
- Error rate: < 10%

---

### Scenario 3: Heavy Load Test (Stress Test)

**Script: `heavy-load-test.js`**

```javascript
import http from 'k6/http';
import { check, sleep } from 'k6';

const BASE_URL = 'http://ec2-65-0-56-84.ap-south-1.compute.amazonaws.com/api';

export const options = {
  stages: [
    { duration: '3m', target: 50 },    // Ramp up to 50 users
    { duration: '10m', target: 50 },   // Hold for 10 minutes
    { duration: '3m', target: 100 },   // Ramp up to 100 users
    { duration: '10m', target: 100 },  // Hold for 10 minutes
    { duration: '3m', target: 0 },     // Ramp down
  ],
  thresholds: {
    http_req_duration: ['p(95)<1000', 'p(99)<2000'],
    http_req_failed: ['rate<0.2'],     // Allow up to 20% errors under stress
  },
};

const users = [
  { email: 'dean1@example.com', password: 'password123' },
  { email: 'dean2@example.com', password: 'password123' },
  { email: 'hod@example.com', password: 'password123' },
  { email: 'teacher@example.com', password: 'password123' },
];

export default function () {
  // Random user selection
  const user = users[Math.floor(Math.random() * users.length)];

  // Login
  const loginRes = http.post(`${BASE_URL}/auth/login`, {
    email: user.email,
    password: user.password,
  });

  const token = loginRes.json('token');

  if (token) {
    // Multiple concurrent requests
    const responses = http.batch([
      ['GET', `${BASE_URL}/dean/overview`, { headers: { Authorization: `Bearer ${token}` } }],
      ['GET', `${BASE_URL}/dean/departments`, { headers: { Authorization: `Bearer ${token}` } }],
      ['GET', `${BASE_URL}/notifications?limit=50`, { headers: { Authorization: `Bearer ${token}` } }],
      ['GET', `${BASE_URL}/dean/analytics`, { headers: { Authorization: `Bearer ${token}` } }],
    ]);

    check(responses[0], { 'Overview ok': (r) => r.status === 200 });
    check(responses[1], { 'Departments ok': (r) => r.status === 200 });
    check(responses[2], { 'Notifications ok': (r) => r.status === 200 });
    check(responses[3], { 'Analytics ok': (r) => r.status === 200 });
  }

  sleep(2);
}
```

**Run:**
```bash
k6 run heavy-load-test.js
```

**Expected Results:**
- System should handle 100 concurrent users
- 95th percentile response time: < 1000ms
- Error rate: < 20%
- System should recover after stress ends

---

### Scenario 4: Spike Test

**Script: `spike-test.js`**

```javascript
import http from 'k6/http';
import { check, sleep } from 'k6';

const BASE_URL = 'http://ec2-65-0-56-84.ap-south-1.compute.amazonaws.com/api';

export const options = {
  stages: [
    { duration: '1m', target: 10 },    // Normal load
    { duration: '30s', target: 100 },  // Sudden spike to 100 users
    { duration: '30s', target: 100 },  // Hold spike
    { duration: '1m', target: 10 },    // Return to normal
    { duration: '1m', target: 0 },     // Cool down
  ],
  thresholds: {
    http_req_duration: ['p(95)<1500'],
    http_req_failed: ['rate<0.3'],
  },
};

export default function () {
  const loginRes = http.post(`${BASE_URL}/auth/login`, {
    email: 'dean@example.com',
    password: 'password123',
  });

  const token = loginRes.json('token');

  // Simulate realistic user activity
  const requests = [
    http.get(`${BASE_URL}/dean/overview`, {
      headers: { Authorization: `Bearer ${token}` },
    }),
    http.get(`${BASE_URL}/dean/departments`, {
      headers: { Authorization: `Bearer ${token}` },
    }),
    http.get(`${BASE_URL}/notifications?limit=50`, {
      headers: { Authorization: `Bearer ${token}` },
    }),
  ];

  requests.forEach((res) => {
    check(res, {
      'Status is 200': (r) => r.status === 200,
    });
  });

  sleep(1);
}
```

**Run:**
```bash
k6 run spike-test.js
```

**Expected Results:**
- System should handle sudden spike to 100 users
- Response time degradation should be graceful
- System should recover when load returns to normal
- No crashed services

---

### Scenario 5: Soak Test (Long Duration)

**Script: `soak-test.js`**

```javascript
import http from 'k6/http';
import { check, sleep } from 'k6';

const BASE_URL = 'http://ec2-65-0-56-84.ap-south-1.compute.amazonaws.com/api';

export const options = {
  stages: [
    { duration: '2m', target: 15 },    // Ramp up
    { duration: '1h', target: 15 },    // Hold for 1 hour (soak)
    { duration: '2m', target: 0 },     // Ramp down
  ],
  thresholds: {
    http_req_duration: ['p(95)<500'],
    http_req_failed: ['rate<0.1'],
  },
};

export default function () {
  const loginRes = http.post(`${BASE_URL}/auth/login`, {
    email: 'dean@example.com',
    password: 'password123',
  });

  const token = loginRes.json('token');

  // Simulate realistic user behavior
  http.get(`${BASE_URL}/dean/overview`, {
    headers: { Authorization: `Bearer ${token}` },
  });

  http.get(`${BASE_URL}/notifications?limit=50`, {
    headers: { Authorization: `Bearer ${token}` },
  });

  // Random think time between 2-5 seconds
  const thinkTime = 2000 + Math.random() * 3000;
  sleep(thinkTime / 1000);
}
```

**Run:**
```bash
k6 run soak-test.js
```

**Expected Results:**
- No memory leaks
- Consistent response times over 1 hour
- No degradation in performance
- All endpoints remain stable

---

## Apache JMeter Setup

### Installation

1. **Download JMeter**
   - Go to: https://jmeter.apache.org/download_jmeter.cgi
   - Download latest version

2. **Extract and Run**
   ```bash
   # Extract
   unzip apache-jmeter-5.x.x.zip
   cd apache-jmeter-5.x.x

   # Run (Windows)
   bin\jmeter.bat

   # Run (Mac/Linux)
   bin/jmeter.sh
   ```

### Creating a Test Plan in JMeter

1. **New Test Plan**
   - File > New > Test Plan

2. **Add Thread Group**
   - Right-click on Test Plan > Add > Threads (Users) > Thread Group
   - Set Number of Threads: 50
   - Ramp-up Period: 60 (seconds)
   - Loop Count: 2

3. **Add HTTP Request**
   - Right-click on Thread Group > Add > Sampler > HTTP Request
   - Server Name: ec2-65-0-56-84.ap-south-1.compute.amazonaws.com
   - Port: 80
   - Path: /api/auth/login
   - Method: POST
   - Body Data:
     ```
     {
       "email": "dean@example.com",
       "password": "password123"
     }
     ```

4. **Add Listener**
   - Right-click on Thread Group > Add > Listener > View Results Tree
   - Right-click on Thread Group > Add > Listener > Summary Report

5. **Run Test**
   - Click green "Start" button

---

## Load Testing Results Interpretation

### Key Metrics

| Metric | Good | Acceptable | Poor |
|--------|------|-----------|------|
| Response Time (avg) | < 200ms | 200-500ms | > 500ms |
| Response Time (95th) | < 500ms | 500-1000ms | > 1000ms |
| Response Time (99th) | < 1000ms | 1000-2000ms | > 2000ms |
| Error Rate | < 1% | 1-5% | > 5% |
| Throughput | > 100 req/s | 50-100 req/s | < 50 req/s |
| CPU Usage | < 70% | 70-85% | > 85% |
| Memory Usage | < 70% | 70-85% | > 85% |

### Analysis Checklist

- [ ] Response times remain stable under load
- [ ] Error rate stays below 1% for normal load
- [ ] System recovers after spike tests
- [ ] No memory leaks during soak test
- [ ] Throughput meets requirements
- [ ] Database queries are optimized
- [ ] API endpoints are properly cached
- [ ] Load balancer distributes requests evenly
- [ ] No timeouts or connection issues
- [ ] Server resources within acceptable limits

---

## Performance Optimization Recommendations

### If Response Times Are High

1. **Database Optimization**
   - Add indexes to frequently queried fields
   - Use pagination for large datasets
   - Implement caching (Redis)

2. **API Optimization**
   - Reduce payload size
   - Use compression (gzip)
   - Implement rate limiting
   - Use CDN for static assets

3. **Server Optimization**
   - Increase server capacity
   - Enable clustering
   - Use load balancer
   - Optimize database queries

### If Error Rate Is High

1. **Check Logs**
   - Look for specific error patterns
   - Check database connection pool
   - Verify authentication failures

2. **Increase Resources**
   - More database connections
   - Increase server memory
   - More worker processes

3. **Rate Limiting**
   - Implement request throttling
   - Queue requests
   - Graceful degradation

---

## Automated Load Testing CI/CD Integration

### GitHub Actions Example

Create `.github/workflows/load-test.yml`:

```yaml
name: Load Testing

on:
  schedule:
    - cron: '0 2 * * *'  # Run daily at 2 AM

jobs:
  load-test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2

      - name: Install k6
        run: sudo apt-get install k6

      - name: Run Light Load Test
        run: k6 run load-test.js

      - name: Run Medium Load Test
        if: always()
        run: k6 run medium-load-test.js

      - name: Upload Results
        if: always()
        uses: actions/upload-artifact@v2
        with:
          name: load-test-results
          path: results/
```

---

## Monitoring During Load Tests

### Metrics to Monitor

1. **Application Metrics**
   - Request response time
   - Error rate
   - Throughput (requests/second)
   - Active connections

2. **Server Metrics**
   - CPU usage
   - Memory usage
   - Disk I/O
   - Network bandwidth

3. **Database Metrics**
   - Query response time
   - Connection pool usage
   - Lock wait time
   - Query execution time

### Tools for Monitoring

- **New Relic** - Application Performance Monitoring
- **DataDog** - Infrastructure Monitoring
- **Prometheus** - Metrics collection
- **Grafana** - Visualization
- **CloudWatch** - AWS monitoring

---

## Load Testing Schedule

```
Week 1: Baseline Tests
- Run light, medium, heavy tests
- Document baseline metrics
- Identify bottlenecks

Week 2: Optimization
- Implement optimizations
- Re-run tests
- Compare with baseline

Week 3: Stress & Spike Tests
- Test extreme scenarios
- Verify recovery
- Document limits

Week 4: Production Validation
- Soak tests
- Real-world simulation
- Final performance validation
```

---

## Conclusion

Load testing is essential for ensuring system reliability. Regular testing helps identify issues before they affect users in production.

For questions or issues, contact your DevOps/Infrastructure team.
