# API Testing Guide for SGT-LMS

## Overview

This guide provides step-by-step instructions for testing all APIs in the SGT-LMS system using Postman, cURL, or any HTTP client.

---

## Quick Start

### Prerequisites
- Postman or similar API testing tool
- Valid user credentials
- Server URL: `http://ec2-65-0-56-84.ap-south-1.compute.amazonaws.com`
- API Base Path: `/api`

### Authentication Flow

1. **Login to get token**
   ```
   POST /api/auth/login
   {
     "email": "dean@example.com",
     "password": "password123"
   }
   ```

2. **Copy the token from response**
   ```
   Response: { "token": "eyJhbGciOiJIUzI1NiIs..." }
   ```

3. **Use token in all subsequent requests**
   ```
   Header: Authorization: Bearer eyJhbGciOiJIUzI1NiIs...
   ```

---

## Testing Scenarios by Role

### 1. Dean Testing

#### Scenario 1.1: Login as Dean
```
POST http://ec2-65-0-56-84.ap-south-1.compute.amazonaws.com/api/auth/login

Body (JSON):
{
  "email": "dean@school.com",
  "password": "password123"
}

Expected Response (200 OK):
{
  "token": "eyJhbGciOiJIUzI1NiIs...",
  "user": {
    "_id": "60f7b3c9e8f4a5b6c8d9e0f1",
    "name": "Principal Smith",
    "email": "dean@school.com",
    "role": "dean"
  }
}
```

#### Scenario 1.2: Get Dashboard Stats
```
GET http://ec2-65-0-56-84.ap-south-1.compute.amazonaws.com/api/dean/overview
Header: Authorization: Bearer {{token}}

Expected Response (200 OK):
{
  "school": {
    "_id": "60f7b3c9e8f4a5b6c8d9e0f2",
    "name": "Global High School"
  },
  "stats": {
    "departments": 5,
    "teachers": 45,
    "courses": 120,
    "students": 1200
  }
}
```

#### Scenario 1.3: View Received Announcements
```
GET http://ec2-65-0-56-84.ap-south-1.compute.amazonaws.com/api/notifications?limit=50
Header: Authorization: Bearer {{token}}

Expected Response (200 OK):
{
  "notifications": [
    {
      "_id": "61f7b3c9e8f4a5b6c8d9e0f3",
      "message": "New announcement from Admin",
      "type": "announcement",
      "read": false,
      "createdAt": "2025-12-07T10:30:00Z",
      "announcement": {
        "_id": "62f7b3c9e8f4a5b6c8d9e0f4",
        "message": "Full announcement message content",
        "title": "Important Update"
      }
    }
  ],
  "total": 45,
  "page": 1
}

Test Steps:
1. Verify you receive your notifications
2. Check expandedAnnouncement state changes when clicking
3. Verify full message displays when expanded
4. Verify scrollbar appears if notifications > 3
```

#### Scenario 1.4: Create Announcement
```
POST http://ec2-65-0-56-84.ap-south-1.compute.amazonaws.com/api/dean/announcement
Header: Authorization: Bearer {{token}}
Content-Type: application/json

Body (JSON):
{
  "title": "Exam Schedule Update",
  "message": "The final examinations will be held from December 15-31, 2025...",
  "targetRoles": ["teacher", "student"],
  "targetSchools": [],
  "schoolScope": "mySchool",
  "teachers": [],
  "hods": [],
  "sections": []
}

Expected Response (201 Created):
{
  "_id": "63f7b3c9e8f4a5b6c8d9e0f5",
  "title": "Exam Schedule Update",
  "message": "The final examinations...",
  "createdAt": "2025-12-07T11:00:00Z",
  "recipientsCount": 250,
  "status": "published"
}

Test Validation:
- Check recipientsCount > 0
- Verify status is "published"
- Confirm createdAt is current timestamp
```

#### Scenario 1.5: Get Department List
```
GET http://ec2-65-0-56-84.ap-south-1.compute.amazonaws.com/api/dean/departments
Header: Authorization: Bearer {{token}}

Expected Response (200 OK):
[
  {
    "_id": "64f7b3c9e8f4a5b6c8d9e0f6",
    "name": "Computer Science",
    "code": "CS",
    "hod": {
      "_id": "65f7b3c9e8f4a5b6c8d9e0f7",
      "name": "Dr. Johnson"
    },
    "teacherCount": 12,
    "studentCount": 300
  },
  {
    "_id": "66f7b3c9e8f4a5b6c8d9e0f8",
    "name": "Electronics",
    "code": "EC",
    "hod": {
      "_id": "67f7b3c9e8f4a5b6c8d9e0f9",
      "name": "Dr. Williams"
    },
    "teacherCount": 8,
    "studentCount": 200
  }
]

Validation:
- Array length should match departments count
- Each department has hod assigned
- Teacher and student counts are > 0
```

#### Scenario 1.6: Assign HOD to Department
```
PUT http://ec2-65-0-56-84.ap-south-1.compute.amazonaws.com/api/dean/department/{{dept_id}}/hod/{{hod_id}}
Header: Authorization: Bearer {{token}}
Content-Type: application/json

Expected Response (200 OK):
{
  "message": "HOD assigned successfully",
  "department": {
    "_id": "64f7b3c9e8f4a5b6c8d9e0f6",
    "name": "Computer Science",
    "hod": "65f7b3c9e8f4a5b6c8d9e0f7"
  }
}

Validation:
- Department hod field is updated
- Response message confirms success
```

#### Scenario 1.7: Get Analytics
```
GET http://ec2-65-0-56-84.ap-south-1.compute.amazonaws.com/api/dean/analytics?startDate=2025-09-01&endDate=2025-12-31&metric=engagement
Header: Authorization: Bearer {{token}}

Expected Response (200 OK):
{
  "period": "2025-09-01 to 2025-12-31",
  "metric": "engagement",
  "metrics": {
    "totalCourses": 120,
    "activeStudents": 900,
    "averageProgress": 65.5,
    "engagement": 78.2,
    "videoWatchTime": 145600,
    "documentReads": 5600,
    "quizAttempts": 2300
  },
  "trend": "increasing"
}

Validation:
- engagement value is between 0-100
- activeStudents <= total students
- averageProgress is between 0-100
```

---

### 2. HOD Testing

#### Scenario 2.1: Login as HOD
```
POST http://ec2-65-0-56-84.ap-south-1.compute.amazonaws.com/api/auth/login

Body (JSON):
{
  "email": "hod@school.com",
  "password": "password123"
}

Expected Response (200 OK):
{
  "token": "eyJhbGciOiJIUzI1NiIs...",
  "user": {
    "_id": "68f7b3c9e8f4a5b6c8d9e0fa",
    "name": "Dr. Johnson",
    "email": "hod@school.com",
    "role": "hod"
  }
}
```

#### Scenario 2.2: Get HOD Overview
```
GET http://ec2-65-0-56-84.ap-south-1.compute.amazonaws.com/api/hod/overview
Header: Authorization: Bearer {{token}}

Expected Response (200 OK):
{
  "department": {
    "_id": "64f7b3c9e8f4a5b6c8d9e0f6",
    "name": "Computer Science"
  },
  "stats": {
    "teachers": 12,
    "courses": 40,
    "students": 300,
    "pendingApprovals": 5,
    "totalCourses": 40
  }
}

Validation:
- pendingApprovals >= 0
- teachers, courses, students all > 0
```

#### Scenario 2.3: Get Pending Content Approvals
```
GET http://ec2-65-0-56-84.ap-south-1.compute.amazonaws.com/api/hod/content-approvals
Header: Authorization: Bearer {{token}}

Expected Response (200 OK):
[
  {
    "_id": "69f7b3c9e8f4a5b6c8d9e0fb",
    "type": "video",
    "title": "Module 1: Introduction to Programming",
    "submittedBy": {
      "_id": "70f7b3c9e8f4a5b6c8d9e0fc",
      "name": "Dr. Smith"
    },
    "course": {
      "title": "Advanced Programming"
    },
    "status": "pending",
    "submittedAt": "2025-12-06T15:30:00Z"
  },
  {
    "_id": "71f7b3c9e8f4a5b6c8d9e0fd",
    "type": "document",
    "title": "Lecture Notes - Data Structures",
    "submittedBy": {
      "_id": "72f7b3c9e8f4a5b6c8d9e0fe",
      "name": "Dr. Brown"
    },
    "course": {
      "title": "Data Structures"
    },
    "status": "pending",
    "submittedAt": "2025-12-05T10:15:00Z"
  }
]

Validation:
- Each approval has status "pending"
- submittedAt timestamp exists
- type is either "video" or "document"
```

#### Scenario 2.4: Approve Content
```
POST http://ec2-65-0-56-84.ap-south-1.compute.amazonaws.com/api/hod/content-approvals/{{approval_id}}/approve
Header: Authorization: Bearer {{token}}
Content-Type: application/json

Body (JSON):
{
  "remarks": "Good quality content, approved for students"
}

Expected Response (200 OK):
{
  "message": "Content approved successfully",
  "approval": {
    "_id": "69f7b3c9e8f4a5b6c8d9e0fb",
    "status": "approved",
    "approvedAt": "2025-12-07T11:45:00Z",
    "remarks": "Good quality content, approved for students"
  }
}

Validation:
- status changes to "approved"
- approvedAt timestamp is current
- remarks are saved correctly
```

#### Scenario 2.5: Reject Content
```
POST http://ec2-65-0-56-84.ap-south-1.compute.amazonaws.com/api/hod/content-approvals/{{approval_id}}/reject
Header: Authorization: Bearer {{token}}
Content-Type: application/json

Body (JSON):
{
  "remarks": "Please improve video quality and resubmit"
}

Expected Response (200 OK):
{
  "message": "Content rejected successfully",
  "approval": {
    "_id": "71f7b3c9e8f4a5b6c8d9e0fd",
    "status": "rejected",
    "rejectedAt": "2025-12-07T11:50:00Z",
    "remarks": "Please improve video quality and resubmit"
  }
}

Validation:
- status changes to "rejected"
- rejectedAt timestamp is current
- remarks are saved for teacher feedback
```

#### Scenario 2.6: Quiz Unlock Dashboard
```
GET http://ec2-65-0-56-84.ap-south-1.compute.amazonaws.com/api/hod/quiz-unlock-dashboard
Header: Authorization: Bearer {{token}}

Expected Response (200 OK):
{
  "pendingRequests": 3,
  "quizzes": [
    {
      "_id": "73f7b3c9e8f4a5b6c8d9e0ff",
      "title": "Mid-term Exam",
      "course": "Advanced Programming",
      "lockedCount": 5,
      "requestedCount": 3,
      "unlockedCount": 2
    }
  ]
}

Validation:
- requestedCount <= lockedCount
- pendingRequests matches count of requests
```

#### Scenario 2.7: Unlock Quiz for Student
```
POST http://ec2-65-0-56-84.ap-south-1.compute.amazonaws.com/api/hod/quiz/{{quiz_id}}/unlock
Header: Authorization: Bearer {{token}}
Content-Type: application/json

Body (JSON):
{
  "studentId": "74f7b3c9e8f4a5b6c8d9e100",
  "reason": "Medical emergency during exam"
}

Expected Response (200 OK):
{
  "message": "Quiz unlocked successfully",
  "quiz": {
    "_id": "73f7b3c9e8f4a5b6c8d9e0ff",
    "studentId": "74f7b3c9e8f4a5b6c8d9e100",
    "unlockedAt": "2025-12-07T12:00:00Z",
    "unlockedBy": "68f7b3c9e8f4a5b6c8d9e0fa",
    "reason": "Medical emergency during exam"
  }
}

Validation:
- unlockedAt timestamp is current
- unlockedBy matches current HOD ID
- reason is recorded for audit
```

---

### 3. Teacher Testing

#### Scenario 3.1: Login as Teacher
```
POST http://ec2-65-0-56-84.ap-south-1.compute.amazonaws.com/api/auth/login

Body (JSON):
{
  "email": "teacher@school.com",
  "password": "password123"
}

Expected Response (200 OK):
{
  "token": "eyJhbGciOiJIUzI1NiIs...",
  "user": {
    "_id": "70f7b3c9e8f4a5b6c8d9e0fc",
    "name": "Dr. Smith",
    "email": "teacher@school.com",
    "role": "teacher"
  }
}
```

#### Scenario 3.2: Get My Courses
```
GET http://ec2-65-0-56-84.ap-south-1.compute.amazonaws.com/api/teacher/courses
Header: Authorization: Bearer {{token}}

Expected Response (200 OK):
[
  {
    "_id": "75f7b3c9e8f4a5b6c8d9e101",
    "title": "Advanced Programming",
    "code": "CS301",
    "description": "Learn advanced programming concepts",
    "sections": [
      {
        "_id": "76f7b3c9e8f4a5b6c8d9e102",
        "name": "Section A",
        "studentCount": 50
      }
    ],
    "units": 5,
    "videos": 15,
    "documents": 8,
    "quizzes": 4
  }
]

Validation:
- Course has title, code, description
- Sections array contains at least one section
- Count numbers (units, videos, documents) >= 0
```

#### Scenario 3.3: Get Course Details
```
GET http://ec2-65-0-56-84.ap-south-1.compute.amazonaws.com/api/teacher/course/{{course_id}}
Header: Authorization: Bearer {{token}}

Expected Response (200 OK):
{
  "_id": "75f7b3c9e8f4a5b6c8d9e101",
  "title": "Advanced Programming",
  "code": "CS301",
  "sections": [...],
  "units": [
    {
      "_id": "77f7b3c9e8f4a5b6c8d9e103",
      "title": "Unit 1: Basics",
      "description": "Fundamentals of programming",
      "videoCount": 3,
      "documentCount": 2
    }
  ],
  "videos": [
    {
      "_id": "78f7b3c9e8f4a5b6c8d9e104",
      "title": "Video Title",
      "duration": 3600
    }
  ],
  "documents": [...],
  "quizzes": [...]
}

Validation:
- Each unit has title and count of content
- Videos have duration in seconds
- All content is accessible
```

#### Scenario 3.4: Upload Video
```
POST http://ec2-65-0-56-84.ap-south-1.compute.amazonaws.com/api/teacher/video/upload
Header: Authorization: Bearer {{token}}
Content-Type: multipart/form-data

Form Data:
{
  "courseId": "75f7b3c9e8f4a5b6c8d9e101",
  "unitId": "77f7b3c9e8f4a5b6c8d9e103",
  "title": "Introduction to Functions",
  "description": "Learn about function definitions and calls",
  "duration": 1800,
  "file": <select video file>
}

Expected Response (201 Created):
{
  "_id": "78f7b3c9e8f4a5b6c8d9e104",
  "title": "Introduction to Functions",
  "description": "Learn about function definitions and calls",
  "url": "s3://lms-bucket/videos/78f7b3c9e8f4a5b6c8d9e104.mp4",
  "duration": 1800,
  "status": "uploaded",
  "uploadedAt": "2025-12-07T13:00:00Z"
}

Test Notes:
- Use a small video file (< 50MB) for testing
- Note the video URL for playback testing
- Status should be "uploaded"
```

#### Scenario 3.5: Upload Document
```
POST http://ec2-65-0-56-84.ap-south-1.compute.amazonaws.com/api/teacher/document/upload
Header: Authorization: Bearer {{token}}
Content-Type: multipart/form-data

Form Data:
{
  "courseId": "75f7b3c9e8f4a5b6c8d9e101",
  "unitId": "77f7b3c9e8f4a5b6c8d9e103",
  "title": "Lecture Notes - Functions",
  "description": "Comprehensive notes on programming functions",
  "file": <select PDF file>
}

Expected Response (201 Created):
{
  "_id": "79f7b3c9e8f4a5b6c8d9e105",
  "title": "Lecture Notes - Functions",
  "description": "Comprehensive notes on programming functions",
  "url": "s3://lms-bucket/documents/79f7b3c9e8f4a5b6c8d9e105.pdf",
  "fileSize": 2048000,
  "uploadedAt": "2025-12-07T13:05:00Z"
}

Validation:
- fileSize is recorded correctly
- URL is accessible
- Document preview available
```

#### Scenario 3.6: Create Quiz
```
POST http://ec2-65-0-56-84.ap-south-1.compute.amazonaws.com/api/teacher/quiz/create
Header: Authorization: Bearer {{token}}
Content-Type: application/json

Body (JSON):
{
  "courseId": "75f7b3c9e8f4a5b6c8d9e101",
  "title": "Unit 1 Quiz",
  "description": "Assessment for Unit 1 - Basics",
  "totalPoints": 100,
  "duration": 60,
  "passingScore": 50,
  "questions": [
    {
      "question": "What is a function?",
      "type": "multiple_choice",
      "options": [
        "A reusable block of code",
        "A variable",
        "A loop",
        "A comment"
      ],
      "correctAnswer": "A reusable block of code",
      "points": 10
    },
    {
      "question": "True or False: Functions can return multiple values",
      "type": "true_false",
      "correctAnswer": true,
      "points": 10
    }
  ]
}

Expected Response (201 Created):
{
  "_id": "80f7b3c9e8f4a5b6c8d9e106",
  "courseId": "75f7b3c9e8f4a5b6c8d9e101",
  "title": "Unit 1 Quiz",
  "description": "Assessment for Unit 1 - Basics",
  "totalPoints": 100,
  "duration": 60,
  "passingScore": 50,
  "questionCount": 2,
  "createdAt": "2025-12-07T13:30:00Z",
  "status": "draft"
}

Validation:
- questionCount matches array length
- totalPoints equals sum of question points
- passingScore <= totalPoints
- status is "draft" initially
```

#### Scenario 3.7: Get Analytics
```
GET http://ec2-65-0-56-84.ap-south-1.compute.amazonaws.com/api/teacher/analytics?courseId={{course_id}}&startDate=2025-09-01&endDate=2025-12-31
Header: Authorization: Bearer {{token}}

Expected Response (200 OK):
{
  "course": "Advanced Programming",
  "totalStudents": 150,
  "activeStudents": 142,
  "averageProgress": 72.5,
  "videoWatchStats": {
    "totalVideos": 15,
    "averageWatchTime": 45,
    "completionRate": 85
  },
  "documentReadStats": {
    "totalDocuments": 8,
    "averageReadCount": 6,
    "completionRate": 75
  },
  "quizPerformance": {
    "averageScore": 78,
    "passRate": 88,
    "attemptCount": 450
  }
}

Validation:
- activeStudents <= totalStudents
- All percentages between 0-100
- averageScore between 0-100
- passRate between 0-100
```

---

### 4. Student Testing

#### Scenario 4.1: Login as Student
```
POST http://ec2-65-0-56-84.ap-south-1.compute.amazonaws.com/api/auth/login

Body (JSON):
{
  "email": "student@school.com",
  "password": "password123"
}

Expected Response (200 OK):
{
  "token": "eyJhbGciOiJIUzI1NiIs...",
  "user": {
    "_id": "81f7b3c9e8f4a5b6c8d9e107",
    "name": "John Doe",
    "email": "student@school.com",
    "role": "student"
  }
}
```

#### Scenario 4.2: Get Enrolled Courses
```
GET http://ec2-65-0-56-84.ap-south-1.compute.amazonaws.com/api/student/courses
Header: Authorization: Bearer {{token}}

Expected Response (200 OK):
[
  {
    "_id": "75f7b3c9e8f4a5b6c8d9e101",
    "title": "Advanced Programming",
    "code": "CS301",
    "teacher": {
      "_id": "70f7b3c9e8f4a5b6c8d9e0fc",
      "name": "Dr. Smith"
    },
    "progress": 65,
    "enrolledAt": "2025-09-01",
    "status": "active"
  }
]

Validation:
- progress is between 0-100
- status is either "active", "completed", or "dropped"
- enrolledAt date is in the past
```

#### Scenario 4.3: Get Course Content
```
GET http://ec2-65-0-56-84.ap-south-1.compute.amazonaws.com/api/student/course/{{course_id}}
Header: Authorization: Bearer {{token}}

Expected Response (200 OK):
{
  "_id": "75f7b3c9e8f4a5b6c8d9e101",
  "title": "Advanced Programming",
  "progress": 65,
  "units": [
    {
      "_id": "77f7b3c9e8f4a5b6c8d9e103",
      "title": "Unit 1: Basics",
      "completed": true,
      "videos": [
        {
          "_id": "78f7b3c9e8f4a5b6c8d9e104",
          "title": "Introduction to Functions",
          "watched": true,
          "watchedDuration": 1800
        }
      ],
      "documents": [
        {
          "_id": "79f7b3c9e8f4a5b6c8d9e105",
          "title": "Lecture Notes - Functions",
          "read": true
        }
      ],
      "quizzes": [
        {
          "_id": "80f7b3c9e8f4a5b6c8d9e106",
          "title": "Unit 1 Quiz",
          "attempted": true,
          "score": 85
        }
      ]
    }
  ]
}

Validation:
- Each unit has completion status
- Videos show watched status and duration
- Documents show read status
- Quizzes show attempted status and score
```

#### Scenario 4.4: Get Student Progress
```
GET http://ec2-65-0-56-84.ap-south-1.compute.amazonaws.com/api/student/progress
Header: Authorization: Bearer {{token}}

Expected Response (200 OK):
[
  {
    "courseId": "75f7b3c9e8f4a5b6c8d9e101",
    "courseTitle": "Advanced Programming",
    "progress": 65,
    "videosWatched": 10,
    "videosTotal": 15,
    "documentsRead": 6,
    "documentsTotal": 8,
    "quizzesTaken": 3,
    "quizzesTotal": 4,
    "averageQuizScore": 82
  }
]

Validation:
- videosWatched <= videosTotal
- documentsRead <= documentsTotal
- quizzesTaken <= quizzesTotal
- averageQuizScore between 0-100
- progress calculation = (videosWatched/videosTotal + documentsRead/documentsTotal + quizzesTaken/quizzesTotal) / 3 * 100
```

#### Scenario 4.5: Attempt Quiz
```
POST http://ec2-65-0-56-84.ap-south-1.compute.amazonaws.com/api/student/quiz/{{quiz_id}}/attempt
Header: Authorization: Bearer {{token}}
Content-Type: application/json

Body (JSON):
{
  "answers": [
    {
      "questionId": "82f7b3c9e8f4a5b6c8d9e108",
      "selectedAnswer": "A reusable block of code"
    },
    {
      "questionId": "83f7b3c9e8f4a5b6c8d9e109",
      "selectedAnswer": true
    }
  ]
}

Expected Response (200 OK):
{
  "_id": "84f7b3c9e8f4a5b6c8d9e10a",
  "studentId": "81f7b3c9e8f4a5b6c8d9e107",
  "quizId": "80f7b3c9e8f4a5b6c8d9e106",
  "score": 20,
  "totalPoints": 100,
  "percentage": 20,
  "passed": false,
  "completedAt": "2025-12-07T14:00:00Z"
}

Validation:
- percentage = (score / totalPoints) * 100
- passed = (percentage >= passingScore)
- completedAt is current timestamp
- Each answer is recorded
```

#### Scenario 4.6: Get Quiz Result
```
GET http://ec2-65-0-56-84.ap-south-1.compute.amazonaws.com/api/student/quiz/{{quiz_id}}/result
Header: Authorization: Bearer {{token}}

Expected Response (200 OK):
{
  "quizId": "80f7b3c9e8f4a5b6c8d9e106",
  "quizTitle": "Unit 1 Quiz",
  "attempts": [
    {
      "_id": "84f7b3c9e8f4a5b6c8d9e10a",
      "attemptNumber": 1,
      "score": 20,
      "percentage": 20,
      "passed": false,
      "completedAt": "2025-12-07T14:00:00Z"
    }
  ],
  "bestScore": 20,
  "bestPercentage": 20,
  "passedStatus": false,
  "allowedAttempts": 3,
  "remainingAttempts": 2
}

Validation:
- Each attempt in chronological order
- bestScore >= all individual attempt scores
- remainingAttempts = allowedAttempts - attempt count
```

#### Scenario 4.7: Get Certificate
```
GET http://ec2-65-0-56-84.ap-south-1.compute.amazonaws.com/api/student/certificate/{{course_id}}
Header: Authorization: Bearer {{token}}

Expected Response (200 OK):
{
  "courseId": "75f7b3c9e8f4a5b6c8d9e101",
  "courseTitle": "Advanced Programming",
  "studentName": "John Doe",
  "studentId": "81f7b3c9e8f4a5b6c8d9e107",
  "teacherName": "Dr. Smith",
  "completedDate": "2025-12-07",
  "certificateCode": "SGT-2025-001234",
  "certificateUrl": "s3://lms-bucket/certificates/SGT-2025-001234.pdf",
  "downloadUrl": "http://ec2-65-0-56-84.ap-south-1.compute.amazonaws.com/api/student/certificate/SGT-2025-001234/download"
}

Validation:
- Certificate exists only after course completion
- certificateCode is unique
- certificate URL is accessible
- completedDate matches course completion date
```

---

## Error Handling Test Cases

### Test Case: Unauthorized Access
```
GET http://ec2-65-0-56-84.ap-south-1.compute.amazonaws.com/api/dean/overview
(No Authorization header)

Expected Response (401 Unauthorized):
{
  "error": "No token provided",
  "statusCode": 401
}
```

### Test Case: Invalid Token
```
GET http://ec2-65-0-56-84.ap-south-1.compute.amazonaws.com/api/dean/overview
Authorization: Bearer invalid_token_here

Expected Response (401 Unauthorized):
{
  "error": "Invalid token",
  "statusCode": 401
}
```

### Test Case: Insufficient Permissions
```
GET http://ec2-65-0-56-84.ap-south-1.compute.amazonaws.com/api/admin/schools
Authorization: Bearer {{student_token}}

Expected Response (403 Forbidden):
{
  "error": "Insufficient permissions",
  "statusCode": 403
}
```

### Test Case: Resource Not Found
```
GET http://ec2-65-0-56-84.ap-south-1.compute.amazonaws.com/api/courses/invalid_course_id
Authorization: Bearer {{token}}

Expected Response (404 Not Found):
{
  "error": "Course not found",
  "statusCode": 404
}
```

### Test Case: Validation Error
```
POST http://ec2-65-0-56-84.ap-south-1.compute.amazonaws.com/api/admin/students
Authorization: Bearer {{admin_token}}
Content-Type: application/json

Body (JSON):
{
  "name": "John",
  "email": "invalid-email"
}

Expected Response (400 Bad Request):
{
  "error": "Validation failed",
  "statusCode": 400,
  "details": {
    "email": "Please provide a valid email address",
    "rollNo": "Roll number is required",
    "sectionId": "Section ID is required"
  }
}
```

---

## Performance Test Cases

### Test Case: Response Time
```
Measure response time for each endpoint:

Target Response Times:
- GET endpoints: < 500ms
- POST endpoints: < 1000ms
- File uploads: < 5000ms

Tools:
- Postman: View "Time" in Response section
- cURL: Use -w "%{time_total}\n"
```

### Test Case: Concurrent Requests
```
Simulate multiple users accessing simultaneously:

Test: 10 concurrent login requests
Expected: All succeed within 2 seconds

Tool: Apache JMeter or k6
```

---

## Checklist for Complete API Testing

**Authentication & Authorization**
- [ ] Login with valid credentials
- [ ] Login with invalid credentials
- [ ] Use token in subsequent requests
- [ ] Test expired token refresh
- [ ] Test access without token
- [ ] Test access with invalid token
- [ ] Test role-based access control

**Dean Endpoints**
- [ ] View dashboard overview
- [ ] View departments
- [ ] Assign HOD to department
- [ ] Create announcement
- [ ] View received announcements
- [ ] Get analytics

**HOD Endpoints**
- [ ] View department overview
- [ ] View pending approvals
- [ ] Approve content
- [ ] Reject content
- [ ] View quiz unlock requests
- [ ] Unlock quiz for student

**Teacher Endpoints**
- [ ] View my courses
- [ ] View course details
- [ ] Upload video
- [ ] Upload document
- [ ] Create quiz
- [ ] View analytics

**Student Endpoints**
- [ ] View enrolled courses
- [ ] View course content
- [ ] View progress
- [ ] Attempt quiz
- [ ] View quiz results
- [ ] Download certificate

**Data Validation**
- [ ] All fields properly validated
- [ ] Error messages are clear
- [ ] Response formats are consistent
- [ ] Timestamps are correct

**Edge Cases**
- [ ] Empty search results
- [ ] Large file uploads
- [ ] Concurrent requests
- [ ] High traffic conditions
- [ ] Database timeout scenarios
