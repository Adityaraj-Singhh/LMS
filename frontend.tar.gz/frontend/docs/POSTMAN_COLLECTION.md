# Postman Collection for SGT-LMS API Testing

## Setup Instructions

### 1. Environment Variables Setup

Create a Postman environment with the following variables:

```json
{
  "base_url": "http://ec2-65-0-56-84.ap-south-1.compute.amazonaws.com",
  "api_url": "{{base_url}}/api",
  "token": "",
  "user_id": "",
  "school_id": "",
  "teacher_id": "",
  "student_id": "",
  "course_id": "",
  "quiz_id": "",
  "section_id": "",
  "department_id": "",
  "hod_id": ""
}
```

### 2. Pre-request Script (Add to Collection)

Add this to the collection's pre-request scripts to automatically set up auth:

```javascript
// Auto-refresh token if needed
if (pm.environment.get('token')) {
    pm.request.headers.add({
        key: 'Authorization',
        value: 'Bearer ' + pm.environment.get('token')
    });
}

// Set Content-Type
pm.request.headers.add({
    key: 'Content-Type',
    value: 'application/json'
});
```

### 3. Tests Script (Add to Collection)

Add this to verify responses:

```javascript
// Check response status
if (pm.response.code >= 400) {
    console.error('Error:', pm.response.json());
}

// Save token from login response
if (pm.response.json().token) {
    pm.environment.set('token', pm.response.json().token);
}

// Pretty print response
console.log(JSON.stringify(pm.response.json(), null, 2));
```

---

## API Endpoints Collection

### Authentication Module

#### 1. Login
```
POST /api/auth/login
Content-Type: application/json

Request Body:
{
  "email": "dean@example.com",
  "password": "password123"
}

Response:
{
  "token": "eyJhbGciOiJIUzI1NiIs...",
  "user": {
    "_id": "user_id",
    "name": "Dean Name",
    "email": "dean@example.com",
    "role": "dean"
  }
}
```

#### 2. Logout
```
POST /api/auth/logout
Authorization: Bearer {{token}}

Response:
{
  "message": "Logged out successfully"
}
```

#### 3. Refresh Token
```
POST /api/auth/refresh-token
Authorization: Bearer {{token}}

Response:
{
  "token": "new_token_here"
}
```

#### 4. Change Password
```
POST /api/auth/change-password
Authorization: Bearer {{token}}
Content-Type: application/json

Request Body:
{
  "currentPassword": "old_password",
  "newPassword": "new_password",
  "confirmPassword": "new_password"
}

Response:
{
  "message": "Password changed successfully"
}
```

---

### Dean Module

#### 1. Get Dashboard Overview
```
GET /api/dean/overview
Authorization: Bearer {{token}}

Response:
{
  "school": {
    "_id": "school_id",
    "name": "School Name"
  },
  "stats": {
    "departments": 5,
    "teachers": 45,
    "courses": 120,
    "students": 1200
  }
}
```

#### 2. Get Departments
```
GET /api/dean/departments
Authorization: Bearer {{token}}

Response:
[
  {
    "_id": "dept_id",
    "name": "Computer Science",
    "hod": {
      "_id": "hod_id",
      "name": "Dr. Smith"
    },
    "teacherCount": 10,
    "studentCount": 200
  }
]
```

#### 3. Assign HOD to Department
```
PUT /api/dean/department/{{department_id}}/hod/{{hod_id}}
Authorization: Bearer {{token}}
Content-Type: application/json

Response:
{
  "message": "HOD assigned successfully",
  "department": {
    "_id": "dept_id",
    "hod": "hod_id"
  }
}
```

#### 4. Create Announcement
```
POST /api/dean/announcement
Authorization: Bearer {{token}}
Content-Type: application/json

Request Body:
{
  "title": "Announcement Title",
  "message": "Full announcement message here",
  "targetRoles": ["hod", "teacher", "student"],
  "targetAudience": "all",
  "priority": "high",
  "schoolScope": "mySchool"
}

Response:
{
  "_id": "announcement_id",
  "title": "Announcement Title",
  "message": "Full announcement message here",
  "createdAt": "2025-12-07T10:30:00Z",
  "recipientsCount": 250
}
```

#### 5. Get Announcements
```
GET /api/notifications?limit=50
Authorization: Bearer {{token}}

Response:
{
  "notifications": [
    {
      "_id": "notif_id",
      "message": "Announcement title",
      "type": "announcement",
      "read": false,
      "createdAt": "2025-12-07T10:30:00Z",
      "announcement": {
        "_id": "ann_id",
        "message": "Full announcement message",
        "title": "Title"
      }
    }
  ],
  "total": 45,
  "page": 1
}
```

#### 6. Get Analytics
```
GET /api/dean/analytics
Authorization: Bearer {{token}}

Query Parameters:
- startDate: 2025-01-01
- endDate: 2025-12-31
- metric: engagement (or courses, students, progress)

Response:
{
  "period": "2025-01-01 to 2025-12-31",
  "metrics": {
    "totalCourses": 120,
    "activeStudents": 900,
    "averageProgress": 65.5,
    "engagement": 78.2
  }
}
```

---

### HOD Module

#### 1. Get HOD Overview
```
GET /api/hod/overview
Authorization: Bearer {{token}}

Response:
{
  "department": {
    "_id": "dept_id",
    "name": "Computer Science"
  },
  "stats": {
    "teachers": 15,
    "courses": 40,
    "students": 300,
    "pendingApprovals": 5
  }
}
```

#### 2. Get Pending Approvals
```
GET /api/hod/content-approvals
Authorization: Bearer {{token}}

Response:
[
  {
    "_id": "approval_id",
    "type": "video",
    "title": "Content Title",
    "submittedBy": {
      "_id": "teacher_id",
      "name": "Teacher Name"
    },
    "status": "pending",
    "submittedAt": "2025-12-07T10:00:00Z"
  }
]
```

#### 3. Approve Content
```
POST /api/hod/content-approvals/{{approval_id}}/approve
Authorization: Bearer {{token}}
Content-Type: application/json

Request Body:
{
  "remarks": "Approved - good content quality"
}

Response:
{
  "message": "Content approved successfully",
  "approval": {
    "_id": "approval_id",
    "status": "approved",
    "approvedAt": "2025-12-07T11:00:00Z"
  }
}
```

#### 4. Reject Content
```
POST /api/hod/content-approvals/{{approval_id}}/reject
Authorization: Bearer {{token}}
Content-Type: application/json

Request Body:
{
  "remarks": "Please revise the content and resubmit"
}

Response:
{
  "message": "Content rejected successfully",
  "approval": {
    "_id": "approval_id",
    "status": "rejected",
    "rejectedAt": "2025-12-07T11:00:00Z",
    "remarks": "Please revise the content and resubmit"
  }
}
```

#### 5. Get Quiz Unlock Dashboard
```
GET /api/hod/quiz-unlock-dashboard
Authorization: Bearer {{token}}

Response:
{
  "pendingRequests": 3,
  "quizzes": [
    {
      "_id": "quiz_id",
      "title": "Mid-term Quiz",
      "course": "Course Name",
      "lockedCount": 5,
      "requestedCount": 3
    }
  ]
}
```

#### 6. Unlock Quiz
```
POST /api/hod/quiz/{{quiz_id}}/unlock
Authorization: Bearer {{token}}
Content-Type: application/json

Request Body:
{
  "studentId": "student_id",
  "reason": "Medical emergency"
}

Response:
{
  "message": "Quiz unlocked successfully",
  "quiz": {
    "_id": "quiz_id",
    "studentId": "student_id",
    "unlockedAt": "2025-12-07T11:00:00Z"
  }
}
```

---

### Teacher Module

#### 1. Get My Courses
```
GET /api/teacher/courses
Authorization: Bearer {{token}}

Response:
[
  {
    "_id": "course_id",
    "title": "Advanced Programming",
    "code": "CS301",
    "sections": [
      {
        "_id": "section_id",
        "name": "Section A",
        "studentCount": 50
      }
    ]
  }
]
```

#### 2. Get Course Details
```
GET /api/teacher/course/{{course_id}}
Authorization: Bearer {{token}}

Response:
{
  "_id": "course_id",
  "title": "Advanced Programming",
  "code": "CS301",
  "sections": [...],
  "units": [...],
  "videos": [...],
  "documents": [...],
  "quizzes": [...]
}
```

#### 3. Upload Video
```
POST /api/teacher/video/upload
Authorization: Bearer {{token}}
Content-Type: multipart/form-data

Form Data:
- courseId: {{course_id}}
- unitId: {{unit_id}}
- title: "Video Title"
- description: "Video description"
- file: <video_file>
- duration: 3600 (in seconds)
- thumbnail: <thumbnail_image>

Response:
{
  "_id": "video_id",
  "title": "Video Title",
  "url": "s3://bucket/videos/video_id.mp4",
  "duration": 3600,
  "uploadedAt": "2025-12-07T10:00:00Z"
}
```

#### 4. Upload Document
```
POST /api/teacher/document/upload
Authorization: Bearer {{token}}
Content-Type: multipart/form-data

Form Data:
- courseId: {{course_id}}
- unitId: {{unit_id}}
- title: "Document Title"
- description: "Document description"
- file: <pdf_file>

Response:
{
  "_id": "document_id",
  "title": "Document Title",
  "url": "s3://bucket/documents/doc_id.pdf",
  "uploadedAt": "2025-12-07T10:00:00Z"
}
```

#### 5. Create Quiz
```
POST /api/teacher/quiz/create
Authorization: Bearer {{token}}
Content-Type: application/json

Request Body:
{
  "courseId": "{{course_id}}",
  "title": "Quiz 1",
  "description": "First assessment",
  "totalPoints": 100,
  "duration": 60,
  "passingScore": 50,
  "questions": [
    {
      "question": "What is 2+2?",
      "type": "multiple_choice",
      "options": ["3", "4", "5", "6"],
      "correctAnswer": "4",
      "points": 10
    }
  ]
}

Response:
{
  "_id": "quiz_id",
  "title": "Quiz 1",
  "courseId": "course_id",
  "createdAt": "2025-12-07T10:00:00Z"
}
```

#### 6. Get Analytics
```
GET /api/teacher/analytics
Authorization: Bearer {{token}}

Query Parameters:
- courseId: {{course_id}}
- startDate: 2025-01-01
- endDate: 2025-12-31

Response:
{
  "course": "Course Name",
  "totalStudents": 150,
  "averageProgress": 65.5,
  "topicEngagement": [...],
  "videoWatchStats": [...],
  "quizPerformance": [...]
}
```

---

### Student Module

#### 1. Get My Courses
```
GET /api/student/courses
Authorization: Bearer {{token}}

Response:
[
  {
    "_id": "course_id",
    "title": "Advanced Programming",
    "teacher": {
      "_id": "teacher_id",
      "name": "Dr. Johnson"
    },
    "progress": 65,
    "enrolledAt": "2025-09-01"
  }
]
```

#### 2. Get Course Content
```
GET /api/student/course/{{course_id}}
Authorization: Bearer {{token}}

Response:
{
  "_id": "course_id",
  "title": "Advanced Programming",
  "units": [
    {
      "_id": "unit_id",
      "title": "Unit 1",
      "videos": [...],
      "documents": [...],
      "quizzes": [...]
    }
  ],
  "progress": 65
}
```

#### 3. Get Student Progress
```
GET /api/student/progress
Authorization: Bearer {{token}}

Response:
[
  {
    "courseId": "course_id",
    "courseTitle": "Advanced Programming",
    "progress": 65,
    "videosWatched": 25,
    "documentsRead": 10,
    "quizzesTaken": 3
  }
]
```

#### 4. Attempt Quiz
```
POST /api/student/quiz/{{quiz_id}}/attempt
Authorization: Bearer {{token}}
Content-Type: application/json

Request Body:
{
  "answers": [
    {
      "questionId": "q1",
      "selectedAnswer": "option_b"
    },
    {
      "questionId": "q2",
      "selectedAnswer": "option_d"
    }
  ]
}

Response:
{
  "_id": "attempt_id",
  "quizId": "quiz_id",
  "score": 85,
  "totalPoints": 100,
  "percentage": 85,
  "passed": true,
  "completedAt": "2025-12-07T10:30:00Z"
}
```

#### 5. Get Quiz Result
```
GET /api/student/quiz/{{quiz_id}}/result
Authorization: Bearer {{token}}

Response:
{
  "quizId": "quiz_id",
  "quizTitle": "Quiz 1",
  "attempts": [
    {
      "_id": "attempt_id",
      "score": 85,
      "percentage": 85,
      "passed": true,
      "completedAt": "2025-12-07T10:30:00Z",
      "answers": [...]
    }
  ],
  "bestScore": 85
}
```

#### 6. Get Certificate
```
GET /api/student/certificate/{{course_id}}
Authorization: Bearer {{token}}

Response:
{
  "courseId": "course_id",
  "courseTitle": "Advanced Programming",
  "studentName": "John Doe",
  "completedDate": "2025-12-07",
  "certificateUrl": "s3://bucket/certificates/cert_id.pdf",
  "certificateCode": "SGT-2025-001234"
}
```

---

### Admin Module

#### 1. Create Teacher
```
POST /api/admin/teachers
Authorization: Bearer {{token}}
Content-Type: application/json

Request Body:
{
  "name": "Dr. John Smith",
  "email": "john.smith@school.com",
  "password": "TempPassword123",
  "teacherId": "TSH001",
  "phone": "+1234567890",
  "departmentId": "{{department_id}}",
  "qualifications": "Ph.D. Computer Science",
  "experience": 10
}

Response:
{
  "_id": "teacher_id",
  "name": "Dr. John Smith",
  "email": "john.smith@school.com",
  "teacherId": "TSH001",
  "createdAt": "2025-12-07T10:00:00Z"
}
```

#### 2. Bulk Upload Teachers
```
POST /api/admin/teachers/bulk-upload
Authorization: Bearer {{token}}
Content-Type: multipart/form-data

Form Data:
- file: <CSV/Excel file>

CSV Format:
name,email,teacherId,departmentId,qualifications,experience
Dr. John Smith,john@school.com,TSH001,dept_id,Ph.D.,10
Dr. Jane Doe,jane@school.com,TSH002,dept_id,M.Tech.,8

Response:
{
  "uploaded": 2,
  "failed": 0,
  "results": [
    {
      "name": "Dr. John Smith",
      "status": "success",
      "teacherId": "teacher_id"
    }
  ]
}
```

#### 3. Create Student
```
POST /api/admin/students
Authorization: Bearer {{token}}
Content-Type: application/json

Request Body:
{
  "name": "Alice Johnson",
  "email": "alice.j@school.com",
  "password": "TempPassword123",
  "rollNo": "CS2021001",
  "phone": "+1234567890",
  "sectionId": "{{section_id}}",
  "enrollmentDate": "2025-09-01"
}

Response:
{
  "_id": "student_id",
  "name": "Alice Johnson",
  "email": "alice.j@school.com",
  "rollNo": "CS2021001",
  "createdAt": "2025-12-07T10:00:00Z"
}
```

#### 4. Create Department
```
POST /api/admin/departments
Authorization: Bearer {{token}}
Content-Type: application/json

Request Body:
{
  "name": "Computer Science",
  "code": "CS",
  "schoolId": "{{school_id}}",
  "description": "Department of Computer Science and Engineering",
  "hodId": "{{hod_id}}" (optional)
}

Response:
{
  "_id": "department_id",
  "name": "Computer Science",
  "code": "CS",
  "createdAt": "2025-12-07T10:00:00Z"
}
```

#### 5. Create Course
```
POST /api/admin/courses
Authorization: Bearer {{token}}
Content-Type: application/json

Request Body:
{
  "title": "Advanced Programming",
  "code": "CS301",
  "description": "Learn advanced programming concepts",
  "credits": 3,
  "departmentId": "{{department_id}}",
  "syllabus": "http://example.com/syllabus.pdf"
}

Response:
{
  "_id": "course_id",
  "title": "Advanced Programming",
  "code": "CS301",
  "credits": 3,
  "createdAt": "2025-12-07T10:00:00Z"
}
```

#### 6. Create Section
```
POST /api/admin/section
Authorization: Bearer {{token}}
Content-Type: application/json

Request Body:
{
  "name": "CS-Section A",
  "year": 3,
  "semester": "Fall 2025",
  "departmentId": "{{department_id}}",
  "batchStartYear": 2022
}

Response:
{
  "_id": "section_id",
  "name": "CS-Section A",
  "year": 3,
  "studentCount": 0,
  "createdAt": "2025-12-07T10:00:00Z"
}
```

#### 7. Assign Teacher to Course
```
POST /api/admin/section/bulk-teacher-assignment
Authorization: Bearer {{token}}
Content-Type: application/json

Request Body:
{
  "courseId": "{{course_id}}",
  "sectionId": "{{section_id}}",
  "teacherId": "{{teacher_id}}"
}

Response:
{
  "message": "Teacher assigned successfully",
  "assignment": {
    "courseId": "course_id",
    "sectionId": "section_id",
    "teacherId": "teacher_id"
  }
}
```

---

## Error Response Handling

All error responses follow this format:

```json
{
  "error": "Error message",
  "statusCode": 400,
  "details": {
    "field": "error details"
  }
}
```

### Common Status Codes:
- **200** - Success
- **201** - Created
- **400** - Bad Request
- **401** - Unauthorized (invalid/missing token)
- **403** - Forbidden (insufficient permissions)
- **404** - Not Found
- **409** - Conflict
- **500** - Server Error

---

## Testing Checklist

- [ ] Test login and token generation
- [ ] Verify token is automatically added to headers
- [ ] Test each endpoint with valid data
- [ ] Test error handling with invalid data
- [ ] Verify authorization on protected routes
- [ ] Test pagination on list endpoints
- [ ] Test file uploads (video, document, images)
- [ ] Verify response times
- [ ] Test concurrent requests
- [ ] Load test high-traffic endpoints
