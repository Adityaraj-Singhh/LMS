const axios = require('axios');

// Configure axios for HTTPS with self-signed certificate
const axiosInstance = axios.create({
  httpsAgent: new (require('https').Agent)({
    rejectUnauthorized: false // Accept self-signed certificates
  }),
  timeout: 10000
});

const testLoginVariations = async () => {
  const BASE_URL = 'https://3.110.146.56/api';
  const email = 'sourav3@gmail.com';
  
  // Try different password variations
  const passwordsToTry = [
    'sourav3@gmail.com',
    'Sourav@123',
    'sourav3',
    'sourav',
    'Sourav3',
    'password',
    '123456',
    'sourav123'
  ];

  for (const password of passwordsToTry) {
    try {
      console.log(`\n🔐 Trying password: ${password}`);
      
      const response = await axiosInstance.post(`${BASE_URL}/auth/login`, {
        email: email,
        password: password
      }, {
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        }
      });

      if (response.data.success || response.data.token) {
        console.log('✅ LOGIN SUCCESSFUL!');
        console.log('👤 User:', response.data.user?.name || response.data.name);
        console.log('🔑 Token:', response.data.token ? 'Received' : 'Not received');
        console.log('📧 Email:', response.data.user?.email || response.data.email);
        console.log('🎭 Role:', response.data.user?.role || response.data.role);
        return { email, password, token: response.data.token };
      } else {
        console.log('❌ Login failed - no success/token in response');
      }
      
    } catch (error) {
      if (error.response) {
        console.log(`❌ Failed - Status: ${error.response.status}, Message: ${error.response.data?.message || 'Unknown error'}`);
      } else {
        console.log(`❌ Failed - Network error: ${error.message}`);
      }
    }
  }
  
  console.log('\n❌ None of the passwords worked!');
  return null;
};

// Also test if the backend is running
const testBackendHealth = async () => {
  try {
    console.log('🏥 Testing backend health...');
    const response = await axios.get('https://3.110.146.56/api/health');
    console.log('✅ Backend is running');
    return true;
  } catch (error) {
    console.log('❌ Backend not responding:', error.message);
    return false;
  }
};

const runLoginTests = async () => {
  console.log('🚀 Starting Login Tests...');
  
  // Skip health check and go directly to login tests
  console.log('⏩ Skipping health check, testing login directly...');
  
  const credentials = await testLoginVariations();
  
  if (credentials) {
    console.log('\n🎉 FOUND WORKING CREDENTIALS:');
    console.log(`📧 Email: ${credentials.email}`);
    console.log(`🔑 Password: ${credentials.password}`);
    console.log(`🎫 Token: ${credentials.token.substring(0, 20)}...`);
  }
};

runLoginTests();