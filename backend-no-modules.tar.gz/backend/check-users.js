const mongoose = require('mongoose');
require('dotenv').config();

// Import User model
const User = require('./models/User');

const connectDB = async () => {
  try {
    console.log('🔗 Connecting to database...');
    await mongoose.connect(process.env.MONGO_URI);
    console.log('✅ Database connected successfully');
  } catch (error) {
    console.error('❌ Database connection failed:', error.message);
    process.exit(1);
  }
};

const checkUsers = async () => {
  try {
    console.log('\n👥 Checking all users in database...');
    
    // Find all users
    const users = await User.find({}, 'name email role createdAt');
    console.log(`📊 Total users found: ${users.length}`);
    
    users.forEach((user, index) => {
      console.log(`\n👤 User ${index + 1}:`);
      console.log(`   Name: ${user.name}`);
      console.log(`   Email: ${user.email}`);
      console.log(`   Role: ${user.role}`);
      console.log(`   Created: ${user.createdAt}`);
      console.log(`   ID: ${user._id}`);
    });
    
    // Look specifically for sourav users
    console.log('\n🔍 Looking for Sourav users...');
    const souravUsers = await User.find({ 
      $or: [
        { email: { $regex: 'sourav', $options: 'i' } },
        { name: { $regex: 'sourav', $options: 'i' } }
      ]
    });
    
    console.log(`📊 Sourav users found: ${souravUsers.length}`);
    
    souravUsers.forEach((user, index) => {
      console.log(`\n🎯 Sourav User ${index + 1}:`);
      console.log(`   Name: ${user.name}`);
      console.log(`   Email: ${user.email}`);
      console.log(`   Role: ${user.role}`);
      console.log(`   ID: ${user._id}`);
      console.log(`   Has Password: ${user.password ? 'Yes' : 'No'}`);
      console.log(`   Password Length: ${user.password ? user.password.length : 'N/A'} chars`);
    });
    
    // Find students specifically
    console.log('\n🎓 Looking for student users...');
    const students = await User.find({ role: 'student' });
    console.log(`📊 Student users found: ${students.length}`);
    
    students.forEach((student, index) => {
      console.log(`\n🎓 Student ${index + 1}:`);
      console.log(`   Name: ${student.name}`);
      console.log(`   Email: ${student.email}`);
      console.log(`   ID: ${student._id}`);
    });
    
  } catch (error) {
    console.error('❌ Error checking users:', error.message);
  } finally {
    await mongoose.disconnect();
    console.log('\n🔌 Database disconnected');
  }
};

connectDB().then(() => {
  checkUsers();
});