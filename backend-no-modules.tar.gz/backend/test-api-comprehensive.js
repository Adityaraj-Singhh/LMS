const mongoose = require('mongoose');
const axios = require('axios');
require('dotenv').config();

// Import models
const User = require('./models/User');
const Course = require('./models/Course');
const Unit = require('./models/Unit');
const StudentProgress = require('./models/StudentProgress');

const BASE_URL = 'https://3.110.146.56/api';
const TEST_EMAIL = 'sourav3@gmail.com';
const TEST_PASSWORD = 'sourav3@gmail.com';

let authToken = '';

// Database connection
const connectDB = async () => {
  try {
    console.log('🔗 Connecting to database:', process.env.MONGO_URI?.substring(0, 50) + '...');
    await mongoose.connect(process.env.MONGO_URI);
    console.log('✅ Database connected successfully');
  } catch (error) {
    console.error('❌ Database connection failed:', error.message);
    process.exit(1);
  }
};

// Test login and get token
const testLogin = async () => {
  try {
    console.log('\n🔐 Testing Login...');
    console.log('Email:', TEST_EMAIL);
    console.log('Password:', TEST_PASSWORD);

    const response = await axios.post(`${BASE_URL}/auth/login`, {
      email: TEST_EMAIL,
      password: TEST_PASSWORD
    });

    if (response.data.success) {
      authToken = response.data.token;
      console.log('✅ Login successful');
      console.log('👤 User:', response.data.user.name);
      console.log('🎓 Role:', response.data.user.role);
      console.log('🔑 Token received:', authToken ? 'Yes' : 'No');
      return response.data.user;
    } else {
      throw new Error('Login failed: ' + JSON.stringify(response.data));
    }
  } catch (error) {
    console.error('❌ Login failed:', error.response?.data || error.message);
    throw error;
  }
};

// Test get enrolled courses
const testGetCourses = async () => {
  try {
    console.log('\n📚 Testing Get Enrolled Courses...');
    const response = await axios.get(`${BASE_URL}/student/enrolled-courses`, {
      headers: { Authorization: `Bearer ${authToken}` }
    });

    console.log('✅ Courses fetched successfully');
    console.log('📊 Number of courses:', response.data.courses?.length || 0);
    
    if (response.data.courses && response.data.courses.length > 0) {
      response.data.courses.forEach((course, index) => {
        console.log(`📖 Course ${index + 1}:`, course.title, `(${course.courseCode})`);
      });
      return response.data.courses[0]; // Return first course for testing
    }
    
    return null;
  } catch (error) {
    console.error('❌ Get courses failed:', error.response?.data || error.message);
    throw error;
  }
};

// Test get course units (this is the critical API call)
const testGetCourseUnits = async (courseId) => {
  try {
    console.log('\n🎯 Testing Get Course Units...');
    console.log('Course ID:', courseId);
    
    const response = await axios.get(`${BASE_URL}/student/units/${courseId}`, {
      headers: { Authorization: `Bearer ${authToken}` }
    });

    console.log('✅ Units fetched successfully');
    console.log('📊 Response status:', response.status);
    console.log('📊 Number of units:', response.data.units?.length || 0);
    
    if (response.data.units && response.data.units.length > 0) {
      response.data.units.forEach((unit, unitIndex) => {
        console.log(`\n📋 Unit ${unitIndex + 1}: ${unit.title}`);
        console.log(`   📹 Videos: ${unit.videos?.length || 0}`);
        console.log(`   📄 Reading Materials: ${unit.readingMaterials?.length || 0}`);
        
        // Check video completion status
        if (unit.videos && unit.videos.length > 0) {
          unit.videos.forEach((video, videoIndex) => {
            console.log(`   📹 Video ${videoIndex + 1}: ${video.title}`);
            console.log(`      ✅ Completed: ${video.isCompleted ? 'Yes' : 'No'}`);
            console.log(`      🔒 Locked: ${video.isLocked ? 'Yes' : 'No'}`);
          });
        }
        
        // Check reading material completion status
        if (unit.readingMaterials && unit.readingMaterials.length > 0) {
          unit.readingMaterials.forEach((doc, docIndex) => {
            console.log(`   📄 Document ${docIndex + 1}: ${doc.title}`);
            console.log(`      ✅ Read: ${doc.isRead ? 'Yes' : 'No'}`);
            console.log(`      🔒 Locked: ${doc.isLocked ? 'Yes' : 'No'}`);
          });
        }
      });
      
      return response.data.units[0]; // Return first unit for further testing
    }
    
    return null;
  } catch (error) {
    console.error('❌ Get units failed:', error.response?.data || error.message);
    throw error;
  }
};

// Test direct database queries
const testDirectDatabaseQueries = async (userId) => {
  try {
    console.log('\n🗄️ Testing Direct Database Queries...');
    console.log('User ID:', userId);

    // Find user
    const user = await User.findById(userId);
    console.log('👤 User found:', user ? user.name : 'Not found');

    // Find enrolled courses
    const courses = await Course.find({ 
      _id: { $in: user.enrolledCourses } 
    });
    console.log('📚 Enrolled courses:', courses.length);

    if (courses.length > 0) {
      const firstCourse = courses[0];
      console.log('🎯 Testing with course:', firstCourse.title);

      // Find units for this course
      const units = await Unit.find({ course: firstCourse._id }).sort({ order: 1 });
      console.log('📋 Units found:', units.length);

      if (units.length > 0) {
        const firstUnit = units[0];
        console.log('🎯 Testing with unit:', firstUnit.title);
        console.log('📹 Videos in unit:', firstUnit.videos?.length || 0);
        console.log('📄 Reading materials in unit:', firstUnit.readingMaterials?.length || 0);

        // Find student progress
        const progress = await StudentProgress.find({ 
          student: userId,
          course: firstCourse._id 
        });
        console.log('📊 Progress records:', progress.length);

        if (progress.length > 0) {
          progress.forEach((prog, index) => {
            console.log(`📊 Progress ${index + 1}:`);
            console.log(`   Unit: ${prog.unit}`);
            console.log(`   Videos watched: ${prog.videosWatched?.length || 0}`);
            console.log(`   Reading materials completed: ${prog.readingMaterialsCompleted?.length || 0}`);
            console.log(`   All videos watched: ${prog.allVideosWatched}`);
            console.log(`   Unit quiz completed: ${prog.unitQuizCompleted}`);
          });
        }
      }
    }

  } catch (error) {
    console.error('❌ Database query failed:', error.message);
  }
};

// Test mark document as read
const testMarkDocumentRead = async (courseId, unitId, documentId) => {
  try {
    console.log('\n📖 Testing Mark Document as Read...');
    console.log('Course ID:', courseId);
    console.log('Unit ID:', unitId);
    console.log('Document ID:', documentId);

    const response = await axios.post(`${BASE_URL}/student/progress/document`, {
      courseId: courseId,
      unitId: unitId,
      documentId: documentId
    }, {
      headers: { Authorization: `Bearer ${authToken}` }
    });

    console.log('✅ Document marked as read successfully');
    console.log('📊 Response:', response.data);
    
    return response.data;
  } catch (error) {
    console.error('❌ Mark document read failed:', error.response?.data || error.message);
  }
};

// Main test function
const runTests = async () => {
  try {
    await connectDB();
    
    // Test 1: Login
    const user = await testLogin();
    
    // Test 2: Get enrolled courses
    const course = await testGetCourses();
    
    if (course) {
      // Test 3: Get course units (critical test)
      const unit = await testGetCourseUnits(course._id);
      
      // Test 4: Direct database queries
      await testDirectDatabaseQueries(user._id);
      
      // Test 5: Mark document as read (if available)
      if (unit && unit.readingMaterials && unit.readingMaterials.length > 0) {
        await testMarkDocumentRead(course._id, unit._id, unit.readingMaterials[0]._id);
        
        // Test 6: Get units again to see if status changed
        console.log('\n🔄 Re-testing units after marking document as read...');
        await testGetCourseUnits(course._id);
      }
    }
    
    console.log('\n✅ All tests completed!');
    
  } catch (error) {
    console.error('\n❌ Test suite failed:', error.message);
  } finally {
    await mongoose.disconnect();
    console.log('🔌 Database disconnected');
    process.exit(0);
  }
};

// Run the tests
console.log('🚀 Starting Comprehensive API and Database Tests...');
console.log('🌐 Base URL:', BASE_URL);
console.log('📧 Test User:', TEST_EMAIL);
console.log('🗄️ Database:', process.env.MONGO_URI?.substring(0, 50) + '...');

runTests();