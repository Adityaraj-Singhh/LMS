const mongoose = require('mongoose');
require('dotenv').config();

mongoose.connect(process.env.MONGO_URI).then(async () => {
  const ContentArrangement = require('./models/ContentArrangement');
  const Course = require('./models/Course');
  const Video = require('./models/Video');
  
  // Find the course
  const course = await Course.findOne({ title: { $regex: 'dont touch', $options: 'i' } });
  console.log('Course:', course.title);
  console.log('  isLaunched:', course.isLaunched);
  
  // Find approved arrangement
  const arrangement = await ContentArrangement.findOne({
    course: course._id,
    status: 'approved'
  }).sort({ version: -1 });
  
  if (arrangement) {
    console.log('\n✅ Approved arrangement found:');
    console.log('  Status:', arrangement.status);
    console.log('  Items count:', arrangement.items.length);
    console.log('  Items:');
    for (const item of arrangement.items) {
      console.log('    -', item.type, item.title, 'contentId:', item.contentId.toString());
    }
  } else {
    console.log('\n❌ No approved arrangement found');
    
    // Check for any arrangement
    const anyArrangement = await ContentArrangement.findOne({ course: course._id });
    if (anyArrangement) {
      console.log('  Found arrangement with status:', anyArrangement.status);
    }
  }
  
  // Check the video
  const video = await Video.findOne({ title: 'test u7' });
  if (video) {
    console.log('\n📹 Video "test u7":');
    console.log('  isApproved:', video.isApproved);
    console.log('  approvalStatus:', video.approvalStatus);
  }
  
  process.exit(0);
}).catch(err => { console.error(err); process.exit(1); });
