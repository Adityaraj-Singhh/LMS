/**
 * Migration Script: Centralize Quiz Pools
 * 
 * This script merges duplicate QuizPools that have the same course+unit combination
 * into a single centralized pool. After running this script, each course+unit
 * combination will have exactly ONE quiz pool.
 * 
 * Flow:
 * 1. Find all QuizPools grouped by course+unit
 * 2. For groups with multiple pools, merge them into one
 * 3. Update any Unit.quizPool references to point to the merged pool
 * 4. Deactivate or delete the duplicate pools
 * 
 * Run: node backend/scripts/migrate-centralize-quiz-pools.js
 */

require('dotenv').config();
const mongoose = require('mongoose');
const QuizPool = require('../models/QuizPool');
const Unit = require('../models/Unit');
const Quiz = require('../models/Quiz');
const QuizAttempt = require('../models/QuizAttempt');
const Course = require('../models/Course'); // Required for populate

const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/sgt-lms';

async function connectDB() {
  try {
    await mongoose.connect(MONGO_URI);
    console.log('✅ Connected to MongoDB');
  } catch (err) {
    console.error('❌ MongoDB connection error:', err);
    process.exit(1);
  }
}

async function migrateQuizPools() {
  console.log('\n🔄 Starting Quiz Pool Centralization Migration...\n');

  // Step 1: Find all active quiz pools grouped by course+unit
  const poolsWithUnits = await QuizPool.find({ 
    unit: { $exists: true, $ne: null },
    isActive: true 
  }).populate('course', 'title').populate('unit', 'title');

  console.log(`📊 Found ${poolsWithUnits.length} active quiz pools with units\n`);

  // Group by course+unit (skip pools with null course or unit)
  const groupedPools = {};
  poolsWithUnits.forEach(pool => {
    if (!pool.course || !pool.unit || !pool.course._id || !pool.unit._id) {
      console.log(`⚠️ Skipping pool ${pool._id} - missing course or unit reference`);
      return;
    }
    const key = `${pool.course._id.toString()}_${pool.unit._id.toString()}`;
    if (!groupedPools[key]) {
      groupedPools[key] = [];
    }
    groupedPools[key].push(pool);
  });

  // Find groups with duplicates
  const duplicateGroups = Object.entries(groupedPools).filter(([, pools]) => pools.length > 1);
  
  console.log(`🔍 Found ${duplicateGroups.length} course+unit combinations with duplicate pools\n`);

  if (duplicateGroups.length === 0) {
    console.log('✅ No duplicate pools found. Database is already clean!\n');
    return { merged: 0, deactivated: 0 };
  }

  let mergedCount = 0;
  let deactivatedCount = 0;

  for (const [key, pools] of duplicateGroups) {
    const courseName = pools[0].course?.title || 'Unknown Course';
    const unitName = pools[0].unit?.title || 'Unknown Unit';
    
    console.log(`\n📦 Processing: ${courseName} > ${unitName}`);
    console.log(`   Found ${pools.length} pools to merge`);

    // Choose the primary pool (oldest or the one with most quizzes)
    pools.sort((a, b) => {
      // Prefer pool with more quizzes
      const quizDiff = (b.quizzes?.length || 0) - (a.quizzes?.length || 0);
      if (quizDiff !== 0) return quizDiff;
      // If equal, prefer older pool
      return new Date(a.createdAt) - new Date(b.createdAt);
    });

    const primaryPool = pools[0];
    const duplicatePools = pools.slice(1);

    console.log(`   Primary pool: ${primaryPool._id} (${primaryPool.quizzes?.length || 0} quizzes)`);

    // Merge quizzes from duplicate pools into primary
    const allQuizIds = new Set(primaryPool.quizzes.map(q => q.toString()));
    const allContributors = new Set(primaryPool.contributors?.map(c => c.toString()) || []);

    for (const dupPool of duplicatePools) {
      console.log(`   Merging pool: ${dupPool._id} (${dupPool.quizzes?.length || 0} quizzes)`);
      
      // Add quizzes
      if (dupPool.quizzes) {
        dupPool.quizzes.forEach(quizId => {
          allQuizIds.add(quizId.toString());
        });
      }

      // Add contributors
      if (dupPool.contributors) {
        dupPool.contributors.forEach(contribId => {
          allContributors.add(contribId.toString());
        });
      }

      // Update quiz attempts to point to primary pool
      const updatedAttempts = await QuizAttempt.updateMany(
        { quizPool: dupPool._id },
        { $set: { quizPool: primaryPool._id } }
      );
      
      if (updatedAttempts.modifiedCount > 0) {
        console.log(`   ↪ Migrated ${updatedAttempts.modifiedCount} quiz attempts`);
      }

      // Deactivate the duplicate pool
      dupPool.isActive = false;
      await dupPool.save();
      deactivatedCount++;
    }

    // Update primary pool with merged data
    primaryPool.quizzes = Array.from(allQuizIds).map(id => new mongoose.Types.ObjectId(id));
    primaryPool.contributors = Array.from(allContributors).map(id => new mongoose.Types.ObjectId(id));
    await primaryPool.save();

    console.log(`   ✅ Merged into primary pool with ${primaryPool.quizzes.length} total quizzes`);

    // Update Unit.quizPool reference to primary
    await Unit.updateOne(
      { _id: primaryPool.unit },
      { $set: { quizPool: primaryPool._id } }
    );

    mergedCount++;
  }

  console.log('\n' + '='.repeat(60));
  console.log('📊 Migration Summary:');
  console.log(`   - Merged groups: ${mergedCount}`);
  console.log(`   - Deactivated duplicate pools: ${deactivatedCount}`);
  console.log('='.repeat(60) + '\n');

  return { merged: mergedCount, deactivated: deactivatedCount };
}

async function verifyMigration() {
  console.log('🔍 Verifying migration...\n');

  // Check for any remaining duplicates
  const activePools = await QuizPool.find({ 
    unit: { $exists: true, $ne: null },
    isActive: true 
  });

  const groupedPools = {};
  activePools.forEach(pool => {
    const key = `${pool.course.toString()}_${pool.unit.toString()}`;
    if (!groupedPools[key]) {
      groupedPools[key] = [];
    }
    groupedPools[key].push(pool);
  });

  const duplicates = Object.entries(groupedPools).filter(([, pools]) => pools.length > 1);

  if (duplicates.length === 0) {
    console.log('✅ Verification passed: No duplicate pools remaining\n');
    return true;
  } else {
    console.log(`⚠️ Warning: ${duplicates.length} duplicate groups still exist\n`);
    return false;
  }
}

async function main() {
  await connectDB();

  try {
    // Run migration
    const result = await migrateQuizPools();

    // Verify
    const verified = await verifyMigration();

    if (verified) {
      console.log('🎉 Migration completed successfully!\n');
    } else {
      console.log('⚠️ Migration completed with warnings. Please review manually.\n');
    }

    console.log('Next steps:');
    console.log('1. Test quiz pool functionality in the application');
    console.log('2. Verify students can still access their quiz attempts');
    console.log('3. The unique index on QuizPool.{course, unit} will prevent future duplicates\n');

  } catch (error) {
    console.error('❌ Migration failed:', error);
  } finally {
    await mongoose.disconnect();
    console.log('🔌 Disconnected from MongoDB');
  }
}

// Run if executed directly
if (require.main === module) {
  main();
}

module.exports = { migrateQuizPools, verifyMigration };
