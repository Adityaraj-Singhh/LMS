const AWS = require('aws-sdk');
require('dotenv').config();

// Configure AWS SDK
const s3 = new AWS.S3({
  region: process.env.AWS_REGION || 'ap-south-1',
  accessKeyId: process.env.AWS_ACCESS_KEY_ID,
  secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY
});

const bucketName = process.env.AWS_BUCKET || 'newtest-lms';

const corsConfiguration = {
  CORSRules: [
    {
      AllowedOrigins: [
        'http://localhost:3000',
        'https://localhost:3000',
        'http://localhost:3001',
        'https://localhost:3001',
        'https://newtest-lms.s3.ap-south-1.amazonaws.com',
        'https://*.amazonaws.com',
        '*' // Allow all origins for signed URLs
      ],
      AllowedMethods: ['GET', 'HEAD', 'POST', 'PUT', 'DELETE'],
      AllowedHeaders: [
        '*',
        'Authorization',
        'Content-Type',
        'X-Amz-Date',
        'X-Amz-Security-Token',
        'X-Amz-Signature',
        'X-Amz-SignedHeaders',
        'X-Amz-Algorithm',
        'X-Amz-Credential',
        'X-Amz-Expires'
      ],
      ExposeHeaders: [
        'ETag',
        'X-Amz-Request-Id',
        'X-Amz-Id-2'
      ],
      MaxAgeSeconds: 3600
    }
  ]
};

async function setupCORS() {
  try {
    console.log(`🔧 Setting up CORS for bucket: ${bucketName}`);
    
    const params = {
      Bucket: bucketName,
      CORSConfiguration: corsConfiguration
    };

    await s3.putBucketCors(params).promise();
    console.log('✅ CORS configuration applied successfully');
    
    // Verify CORS configuration
    const corsResult = await s3.getBucketCors({ Bucket: bucketName }).promise();
    console.log('📋 Current CORS configuration:', JSON.stringify(corsResult, null, 2));
    
  } catch (error) {
    console.error('❌ Error setting up CORS:', error);
    throw error;
  }
}

// Run the setup
setupCORS().then(() => {
  console.log('🎉 S3 CORS setup completed');
  process.exit(0);
}).catch((error) => {
  console.error('💥 S3 CORS setup failed:', error);
  process.exit(1);
});