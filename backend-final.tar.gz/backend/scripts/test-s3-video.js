require('dotenv').config();
const S3Service = require('../services/s3Service');

const s3Service = new S3Service();
const videoKey = 'videos/admin-1763975369329-955059121.mp4';

console.log('Testing signed URL generation...');
console.log('Video key:', videoKey);

try {
  const signedUrl = s3Service.getSignedUrl(videoKey);
  console.log('✅ Signed URL generated:', signedUrl);
  
  // Test if the object exists
  const AWS = require('aws-sdk');
  const s3 = new AWS.S3({
    region: process.env.AWS_REGION,
    accessKeyId: process.env.AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY
  });
  
  s3.headObject({
    Bucket: process.env.AWS_BUCKET,
    Key: videoKey
  }, (err, data) => {
    if (err) {
      console.log('❌ Object does not exist or access denied:', err.message);
      if (err.code === 'NotFound') {
        console.log('📁 Object key not found in bucket. Please check if the file exists.');
      } else if (err.code === 'Forbidden') {
        console.log('🔒 Access denied. Check IAM permissions.');
      }
    } else {
      console.log('✅ Object exists:', {
        size: data.ContentLength + ' bytes',
        type: data.ContentType,
        lastModified: data.LastModified
      });
    }
  });
} catch (error) {
  console.log('❌ Error generating signed URL:', error.message);
}