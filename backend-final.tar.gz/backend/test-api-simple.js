// Simple API test using native Node.js https module (no axios dependency)
const https = require('https');
const querystring = require('querystring');

// Test login and get units data
async function testAPI() {
  console.log('🚀 Testing API without backend server...\n');

  // Step 1: Login
  console.log('1️⃣ Testing Login...');
  
  const loginData = JSON.stringify({
    email: 'sourav3@gmail.com',
    password: 'sourav3@gmail.com'
  });

  try {
    const loginResponse = await makeRequest('POST', '/api/auth/login', loginData, {
      'Content-Type': 'application/json',
      'Content-Length': Buffer.byteLength(loginData)
    });

    console.log('✅ Login Response Status:', loginResponse.statusCode);
    console.log('📄 Login Response:', loginResponse.data);

    if (loginResponse.data && (loginResponse.data.token || loginResponse.data.success)) {
      const token = loginResponse.data.token;
      console.log('🔑 Token received:', token ? 'YES' : 'NO');

      // Step 2: Get enrolled courses
      console.log('\n2️⃣ Testing Get Enrolled Courses...');
      
      const coursesResponse = await makeRequest('GET', '/api/student/enrolled-courses', null, {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      });

      console.log('✅ Courses Response Status:', coursesResponse.statusCode);
      console.log('📄 Courses Response:', JSON.stringify(coursesResponse.data, null, 2));

      if (coursesResponse.data && coursesResponse.data.courses && coursesResponse.data.courses.length > 0) {
        const courseCode = coursesResponse.data.courses[0]._id || coursesResponse.data.courses[0].courseCode;
        
        // Step 3: Get course units (THE CRITICAL TEST)
        console.log('\n3️⃣ Testing Get Course Units (CRITICAL TEST)...');
        console.log('🎯 Course Code/ID:', courseCode);
        
        const unitsResponse = await makeRequest('GET', `/api/student/units/${courseCode}`, null, {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        });

        console.log('✅ Units Response Status:', unitsResponse.statusCode);
        console.log('📄 Units Response:', JSON.stringify(unitsResponse.data, null, 2));

        // Analyze the response structure
        if (unitsResponse.data && unitsResponse.data.units) {
          console.log('\n🔍 DETAILED ANALYSIS OF UNITS RESPONSE:');
          console.log('📊 Number of units:', unitsResponse.data.units.length);

          unitsResponse.data.units.forEach((unit, index) => {
            console.log(`\n📋 Unit ${index + 1}: ${unit.title}`);
            console.log(`   🆔 Unit ID: ${unit._id}`);
            console.log(`   📹 Videos: ${unit.videos ? unit.videos.length : 0}`);
            console.log(`   📄 Reading Materials: ${unit.readingMaterials ? unit.readingMaterials.length : 0}`);
            console.log(`   🔄 Mixed Content: ${unit.mixedContent ? unit.mixedContent.length : 'NOT FOUND'}`);

            // Check video structure
            if (unit.videos && unit.videos.length > 0) {
              console.log('\n   📹 VIDEO DETAILS:');
              unit.videos.forEach((video, vIndex) => {
                console.log(`     Video ${vIndex + 1}: ${video.title}`);
                console.log(`       ✅ isCompleted: ${video.isCompleted}`);
                console.log(`       🔒 isLocked: ${video.isLocked}`);
                console.log(`       👀 watched: ${video.watched}`);
                console.log(`       📊 percentage: ${video.percentage}`);
              });
            }

            // Check reading materials structure  
            if (unit.readingMaterials && unit.readingMaterials.length > 0) {
              console.log('\n   📄 READING MATERIALS DETAILS:');
              unit.readingMaterials.forEach((doc, dIndex) => {
                console.log(`     Document ${dIndex + 1}: ${doc.title}`);
                console.log(`       ✅ isRead: ${doc.isRead}`);
                console.log(`       🔒 isLocked: ${doc.isLocked}`);
                console.log(`       🌐 url: ${doc.url}`);
                console.log(`       📄 type: ${doc.type}`);
              });
            }
          });
        }

      } else {
        console.log('❌ No courses found in response');
      }

    } else {
      console.log('❌ Login failed - no token received');
    }

  } catch (error) {
    console.error('❌ API Test Error:', error.message);
  }
}

// Helper function to make HTTPS requests
function makeRequest(method, path, data, headers = {}) {
  return new Promise((resolve, reject) => {
    const options = {
      hostname: '3.110.146.56',
      port: 443,
      path: path,
      method: method,
      headers: headers,
      rejectUnauthorized: false // Accept self-signed certificates
    };

    const req = https.request(options, (res) => {
      let body = '';
      
      res.on('data', (chunk) => {
        body += chunk;
      });

      res.on('end', () => {
        try {
          const parsedBody = body ? JSON.parse(body) : {};
          resolve({
            statusCode: res.statusCode,
            headers: res.headers,
            data: parsedBody
          });
        } catch (parseError) {
          resolve({
            statusCode: res.statusCode,
            headers: res.headers,
            data: body
          });
        }
      });
    });

    req.on('error', (error) => {
      reject(error);
    });

    if (data) {
      req.write(data);
    }

    req.end();
  });
}

// Run the test
testAPI();