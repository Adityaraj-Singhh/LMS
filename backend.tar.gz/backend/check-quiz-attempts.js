const mongoose = require("mongoose");
require("dotenv").config();

mongoose.connect(process.env.MONGO_URI).then(async () => {
  const conn = mongoose.connection;
  
  // List collections
  const colls = await conn.db.listCollections().toArray();
  console.log("Collections:", colls.map(c => c.name).join(", "));
  
  // Try to find student progress
  const studentprogresses = await conn.db.collection("studentprogresses").findOne({
    student: new mongoose.Types.ObjectId("692d142e897c8f144067ab4b"),
    course: new mongoose.Types.ObjectId("69241de0ad69646c82eb5394")
  });
  
  console.log("\nStudent Progress from DB:");
  if (studentprogresses && studentprogresses.unitProgress) {
    studentprogresses.unitProgress.forEach(up => {
      console.log({
        unitId: up.unitId?.toString(),
        unlocked: up.unlocked,
        unitQuizPassed: up.unitQuizPassed,
        status: up.status
      });
    });
  } else {
    console.log("Document:", JSON.stringify(studentprogresses, null, 2));
  }
  
  process.exit(0);
}).catch(err => {
  console.error("Error:", err);
  process.exit(1);
});
