require('dotenv').config();
const AWS = require('aws-sdk');

// Configure AWS with credentials from environment
const s3 = new AWS.S3({
  region: process.env.AWS_REGION || 'ap-south-1',
  accessKeyId: process.env.AWS_ACCESS_KEY_ID,
  secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY
});
const bucketName = 'newtest-lms';

console.log('Checking CORS configuration for bucket:', bucketName);

s3.getBucketCors({Bucket: bucketName}, (err, data) => {
  if (err) {
    if (err.code === 'NoSuchCORSConfiguration') {
      console.log('❌ No CORS configuration found on bucket');
    } else {
      console.log('❌ Error checking CORS:', err.message);
    }
  } else {
    console.log('✅ Current CORS configuration:');
    console.log(JSON.stringify(data, null, 2));
  }
});