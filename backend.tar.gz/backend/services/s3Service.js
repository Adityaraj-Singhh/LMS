const AWS = require('aws-sdk');
const cacheService = require('./cacheService');
const { CacheKeys, CacheTTL } = require('./cacheService');

class S3Service {
  constructor() {
    // Configure AWS SDK - using standard environment variable names
    // If AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY are not set,
    // SDK will use instance profile or other credential providers
    const s3Config = {
      region: process.env.AWS_REGION || 'ap-south-1'
    };
    
    // Only add credentials if they are explicitly provided
    if (process.env.AWS_ACCESS_KEY_ID && process.env.AWS_SECRET_ACCESS_KEY) {
      s3Config.accessKeyId = process.env.AWS_ACCESS_KEY_ID;
      s3Config.secretAccessKey = process.env.AWS_SECRET_ACCESS_KEY;
    }
    
    this.s3 = new AWS.S3(s3Config);
    this.bucket = process.env.AWS_BUCKET || 'newtest-lms';
    console.log('🔧 S3Service initialized with bucket:', this.bucket, 'region:', process.env.AWS_REGION);
    console.log('🔑 AWS credentials source:', process.env.AWS_ACCESS_KEY_ID ? 'Environment variables' : 'Instance profile/default provider');
  }

  /**
   * Generate a signed URL for private S3 objects (with Redis caching)
   * Cached URLs are returned in ~5-15ms vs 100-300ms for generation
   * @param {string} key - S3 object key
   * @param {number} expiresIn - Expiration time in seconds (default: 1 hour)
   * @returns {string} - Signed URL
   */
  getSignedUrl(key, expiresIn = 3600) {
    try {
      const params = {
        Bucket: this.bucket,
        Key: key,
        Expires: expiresIn
      };

      const signedUrl = this.s3.getSignedUrl('getObject', params);
      console.log(`Generated signed URL for key: ${key}, expires in: ${expiresIn}s`);
      return signedUrl;
    } catch (error) {
      console.error('Error generating signed URL:', error);
      throw error;
    }
  }

  /**
   * Get signed URL with Redis caching (async version)
   * Use this for better performance - caches URLs to avoid regeneration
   * @param {string} key - S3 object key
   * @param {number} expiresIn - Expiration time in seconds (default: 1 hour)
   * @returns {Promise<string>} - Signed URL (from cache or freshly generated)
   */
  async getSignedUrlCached(key, expiresIn = 3600) {
    try {
      const cacheKey = CacheKeys.signedUrl(key);
      
      // Try cache first
      const cached = await cacheService.get(cacheKey);
      if (cached) {
        return cached;
      }

      // Generate new signed URL
      const params = {
        Bucket: this.bucket,
        Key: key,
        Expires: expiresIn
      };

      const signedUrl = this.s3.getSignedUrl('getObject', params);
      
      // Cache with TTL slightly less than URL expiry (55 minutes if URL expires in 60)
      const cacheTtl = Math.max(60, expiresIn - 300); // At least 1 min, 5 min less than expiry
      await cacheService.set(cacheKey, signedUrl, cacheTtl);
      
      console.log(`Generated & cached signed URL for key: ${key}, expires in: ${expiresIn}s`);
      return signedUrl;
    } catch (error) {
      console.error('Error generating cached signed URL:', error);
      // Fallback to non-cached version
      return this.getSignedUrl(key, expiresIn);
    }
  }

  /**
   * Get object from S3
   * @param {string} key - S3 object key
   * @returns {Promise} - S3 object data
   */
  async getObject(key) {
    try {
      const params = {
        Bucket: this.bucket,
        Key: key
      };

      const result = await this.s3.getObject(params).promise();
      console.log(`Retrieved object from S3: ${key} (${result.ContentLength} bytes)`);
      return result;
    } catch (error) {
      console.error(`Error getting object from S3 (${key}):`, error);
      throw error;
    }
  }

  /**
   * Get file buffer from S3 (for secure document processing)
   * @param {string} key - S3 object key
   * @returns {Promise<Buffer>} - File buffer
   */
  async getFileBuffer(key) {
    try {
      const params = {
        Bucket: this.bucket,
        Key: key
      };

      const result = await this.s3.getObject(params).promise();
      console.log(`Retrieved file buffer from S3: ${key} (${result.ContentLength} bytes)`);
      return result.Body;
    } catch (error) {
      console.error(`Error getting file buffer from S3 (${key}):`, error);
      throw error;
    }
  }

  /**
   * Extract S3 key from full S3 URL
   * @param {string} s3Url - Full S3 URL
   * @returns {string|null} - S3 key or null if invalid
   */
  extractKeyFromUrl(s3Url) {
    try {
      if (!s3Url || !s3Url.startsWith('https://')) {
        return null;
      }

      const url = new URL(s3Url);
      
      // Handle both formats:
      // https://bucket.s3.region.amazonaws.com/key
      // https://s3.region.amazonaws.com/bucket/key
      if (url.hostname.includes('.s3.')) {
        // Format: https://bucket.s3.region.amazonaws.com/key
        return url.pathname.substring(1); // Remove leading slash
      } else if (url.hostname.startsWith('s3.')) {
        // Format: https://s3.region.amazonaws.com/bucket/key
        const pathParts = url.pathname.split('/');
        return pathParts.slice(2).join('/'); // Remove /bucket part
      }
      
      return null;
    } catch (error) {
      console.error('Error extracting key from S3 URL:', error);
      return null;
    }
  }

  /**
   * Check if URL is an S3 URL
   * @param {string} url - URL to check
   * @returns {boolean} - True if S3 URL
   */
  isS3Url(url) {
    return url && url.includes('.s3.') && url.includes('.amazonaws.com');
  }
}

module.exports = S3Service;
